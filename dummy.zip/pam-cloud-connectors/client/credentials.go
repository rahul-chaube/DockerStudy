package client

import (
	"fmt"
	"strings"
)

// Credentials are derived from the JSON config provided while creating a client
type Credentials struct {
	Type                           string           `json:"type"`
	Audience                       string           `json:"audience"`
	SubjectTokenType               string           `json:"subject_token_type"`
	ServiceAccountImpersonationUrl string           `json:"service_account_impersonation_url"`
	TokenUrl                       string           `json:"token_url"`
	CredentialSource               CredentialSource `json:"credential_source"`
}

type CredentialSource struct {
	EnvironmentId               string `json:"environment_id"`
	RegionUrl                   string `json:"region_url"`
	Url                         string `json:"url"`
	RegionalCredVerificationUrl string `json:"regional_cred_verification_url"`
}

// NewCredentials creates new connection credentials to be used for authenticating the client
// project: Project Number
// pool: Pool ID
// provider: Provider ID
// serviceAccountEmail: Service Account Email
func NewCredentials(project, pool, provider, serviceAccountEmail string) Credentials {
	return Credentials{
		Type:                           ExternalAccountType,
		Audience:                       fmt.Sprintf(AudienceFormatString, project, pool, provider),
		SubjectTokenType:               SubjectTokenType,
		ServiceAccountImpersonationUrl: fmt.Sprintf(ServiceAccountImpersonationUrlFormatString, serviceAccountEmail),
		TokenUrl:                       TokenUrl,
		CredentialSource: CredentialSource{
			EnvironmentId:               EnvironmentId,
			RegionUrl:                   RegionUrl,
			Url:                         Url,
			RegionalCredVerificationUrl: RegionalCredVerificationUrl,
		},
	}
}

func (creds Credentials) ServiceAccount() string {
	arr := strings.Split(creds.ServiceAccountImpersonationUrl, "/")
	serv := strings.Split(arr[len(arr)-1], ":")
	return serv[0]
}
