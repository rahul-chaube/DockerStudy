package client

import (
	"context"
	"testing"
)

var TEST_PROJECT_NUMBER string
var TEST_ORAGANIZATION_NUMBER string
var TEST_POOL string
var TEST_PROVIDER string
var TEST_SERVICE_ACCOUNT string

func TestConnection(t *testing.T) {
	ctx := context.Background()
	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		{
			name: "Check Connection - POSITIVE ",
			args: args{
				ctx: context.Background(),
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := client.Run(ctx, DiscoveryPaginationFilter{})
			if err != nil {
				t.Fatal("Error performing discovery: ", err)
			}
		})
	}
}

func TestGCPClient_CheckConnection(t *testing.T) {
	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		{
			name: "Check Connection - POSITIVE ",
			args: args{
				ctx: context.Background(),
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := client.CheckConnection(tt.args.ctx); (err != nil) != tt.wantErr {
				t.Errorf("GCPClient.CheckConnection() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestGCPClient_CheckPermission(t *testing.T) {
	type args struct {
		ctx                context.Context
		projectNumber      string
		organizationNumber string
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		{
			name: "Check Permission - Positive case ",
			args: args{
				ctx:                context.Background(),
				projectNumber:      TEST_PROJECT_NUMBER,
				organizationNumber: TEST_ORAGANIZATION_NUMBER,
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := client.CheckPermission(tt.args.ctx); (err != nil) != tt.wantErr {
				t.Errorf("GCPClient.CheckPermission() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestGCPClient_ListFoldersInOrganization(t *testing.T) {

	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		{
			name: "Valid request",
			args: args{
				ctx: context.Background(),
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := client.ListFoldersInOrganization(tt.args.ctx, nil)
			if (err != nil) != tt.wantErr {
				t.Errorf("GCPClient.ListFoldersInOrganization() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func TestGCPClient_ListProjectsInFolder(t *testing.T) {

	type args struct {
		ctx    context.Context
		folder string
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		{
			name: "Positive Test case ",
			args: args{
				ctx: context.Background(),
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			folders, err := client.ListFoldersInOrganization(ctx, nil)
			if (err != nil) != tt.wantErr {
				t.Errorf("GCPClient.ListFoldersInOrganization() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if len(folders) == 0 {
				t.Log("no folders in organization, skipping...")
				return
			}
			for folder := range folders {
				_, err = client.ListProjectsInFolder(ctx, folder, nil)
				if err != nil {
					t.Errorf("GCPClient.ListProjectsInFolder() error = %v, wantErr %v", err, tt.wantErr)
					return
				}
			}
		})
	}
}
