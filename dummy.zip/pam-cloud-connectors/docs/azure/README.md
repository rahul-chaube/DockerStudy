This is a summary of https://blog.identitydigest.com/azuread-federate-aws/

# Overview

1. An identity in AWS Cloud to which Amazon Cognito will issue a token.
2. Configure Azure AD application or managed identity to trust that AWS identity
3. Get a token for the Amazon Cognito identity and exchange it for a token for an Azure AD workload identity.
4. Assign roles

# Steps

## 1. Set up AWS Identity

1. On console.aws.amazon.com/cognito/v2/identity/identity-pools Create new Cognito Identity pool 
2. Create a custom Authentication Provider with a given Developer Provider Name
3. Get Cognito Identity ID: ```aws cognito-identity get-open-id-token-for-developer-identity --identity-pool-id <the pool id you just created>  --logins <developer provider name>=<a_unique_string_identifying_your_workload> --region <aws region>```

## 2. Configure Azure AD

1. Create a new managed identity on https://portal.azure.com/#view/HubsExtension/BrowseResource/resourceType/Microsoft.ManagedIdentity%2FuserAssignedIdentities
2. Create Federated Credential for the managed identity: ```az identity federated-credential create --name AccessFromAWS --identity-name managed-identity-name --resource-group codesamples-rg --issuer https://cognito-identity.amazonaws.com --subject <Cognito Identity ID> --audience <identity pool id>```

## 3. Cognito-AzureAD token exchange

1. Create a permission policy for the pool with the following actions:
    - GetOpenIdTokenForDeveloperIdentity
    - LookupDeveloperIdentity
    - MergeDeveloperIdentities
    - UnlinkDeveloperIdentities
2. Limit the policy to the specific identity pool via its ARN
3. Assign the Permission Policy to the role that is to be assigned to the Instance/Cluster that will perform the workload
4. Get the AWS token (in code: https://pkg.go.dev/github.com/aws/aws-sdk-go-v2/service/cognitoidentity#Client.GetOpenIdTokenForDeveloperIdentity)
5. Exchange for Azure AD access token:
    - Option 1: https://pkg.go.dev/github.com/Azure/azure-sdk-for-go/sdk/azidentity
    - Option 2: https://pkg.go.dev/github.com/AzureAD/microsoft-authentication-library-for-go

## 4. Assign roles

1. Reader role for the subscription and the top level management group.
2. Directory Readers role for Entra ID (through https://portal.azure.com/#view/Microsoft_AAD_IAM/RolesManagementMenuBlade/~/AllRoles/adminUnitObjectId//resourceScope/%2F search for the Directory Readers role, click on it, and add assignement for the managed identity)

# Azure resource structure

Source: https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/ready/azure-setup-guide/organize-resources

## Resource Hierarchy

- *Management groups* help you manage access, policy, and compliance for multiple subscriptions. All subscriptions in a management group automatically inherit the conditions that are applied to the management group.

- *Subscriptions* logically associate user accounts with the resources that they create. Each subscription has limits or quotas on the amount of resources that it can create and use. Organizations can use subscriptions to manage costs and the resources that are created by users, teams, and projects.

- *Resource groups* are logical containers where you can deploy and manage Azure resources like web apps, databases, and storage accounts.

- *Resources* are instances of services that you can create, such as virtual machines, storage, and SQL databases.

## Inheritance

You can apply management settings, such as policies and role-based access control, at any management level. The level determines how widely the setting is applied. Lower levels inherit settings from higher levels. For example, when you apply a policy to a subscription, that policy applies to all resource groups and resources in that subscription.

## Management groups

Management groups form a tree similar to the GCP folder structure. A management group tree can support up to [six levels of depth](https://learn.microsoft.com/en-us/azure/governance/management-groups/overview#hierarchy-of-management-groups-and-subscriptions). This limit doesn't include the tenant root level or the subscription level.

## Hierarchy of management groups

Source: https://learn.microsoft.com/en-us/azure/governance/management-groups/overview#hierarchy-of-management-groups-and-subscriptions

## Role based access control

Source: https://learn.microsoft.com/en-us/azure/role-based-access-control/overview

### Security Principals

Security principals are the entities where we can assign roles. Similar to the entitied defined in GCP we have:
- Users
- Groups
- Service Principals (like service accounts)
- Managed Identities (identities that can be assumed for specific workloads. ["Applications can use managed identities to obtain Microsoft Entra tokens without having to manage any credentials"](https://learn.microsoft.com/en-us/entra/identity/managed-identities-azure-resources/overview))

### Roles

Role are defined similar to GCP with the difference that they do not only include permissions (Azure term: Actions) but also negatives (NotActions), and also the same defined for Data (DataActions, NotDataActions)

### Scopes

The scope of an assigned role works the same as in GCP. Namely: "In Azure, you can specify a scope at four levels: management group, subscription, resource group, or resource. Scopes are structured in a parent-child relationship. You can assign roles at any of these levels of scope."

### Groups

A key thing to take into account here is that groups can contain subgroups that inherit roles from the level above.

### Access evaluation

The positive fact is that the documentation includes a description of the logic of how to determine if a user has access to a resource. (https://learn.microsoft.com/en-us/azure/role-based-access-control/overview#how-azure-rbac-determines-if-a-user-has-access-to-a-resource)

It might not be used as is but it is an effective blueprint.

1. A user (or service principal) acquires a token for Azure Resource Manager.

The token includes the user's group memberships (including transitive group memberships).

2. The user makes a REST API call to Azure Resource Manager with the token attached.

3. Azure Resource Manager retrieves all the role assignments and deny assignments that apply to the resource upon which the action is being taken.

4. If a deny assignment applies, access is blocked. Otherwise, evaluation continues.

5. Azure Resource Manager narrows the role assignments that apply to this user or their group and determines what roles the user has for this resource.

6. Azure Resource Manager determines if the action in the API call is included in the roles the user has for this resource. If the roles include Actions that have a wildcard (*), the effective permissions are computed by subtracting the NotActions from the allowed Actions. Similarly, the same subtraction is done for any data actions.

Actions - NotActions = Effective management permissions

DataActions - NotDataActions = Effective data permissions

7. If the user doesn't have a role with the action at the requested scope, access is not allowed. Otherwise, any conditions are evaluated.

8. If the role assignment includes conditions, they are evaluated. Otherwise access is allowed.

9. If conditions are met, access is allowed. Otherwise access is not allowed.

# SQL Servers

# Servers client
https://pkg.go.dev/github.com/Azure/azure-sdk-for-go/services/sql/mgmt/2014-04-01/sql#NewServersClient

# Listing
- By resource group: https://pkg.go.dev/github.com/Azure/azure-sdk-for-go/services/sql/mgmt/2014-04-01/sql#ServersClient.ListByResourceGroup
- All: https://pkg.go.dev/github.com/Azure/azure-sdk-for-go/services/sql/mgmt/2014-04-01/sql#ServersClient.List

# For a given server, list role assignments

Role assignment client: https://pkg.go.dev/github.com/Azure/azure-sdk-for-go/services/sql/mgmt/2014-04-01/sql#ServersClient.List

List roles for resource group: https://pkg.go.dev/github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/authorization/armauthorization/v2#RoleAssignmentsClient.NewListForResourceGroupPager

List roles for resource: https://pkg.go.dev/github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/authorization/armauthorization/v2#RoleAssignmentsClient.NewListForResourcePager

Identify principals that hold the role: RoleAssignmentListResult[].RoleAssignment.Properties.PrincipalID https://pkg.go.dev/github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/authorization/armauthorization/v2#RoleAssignmentProperties