package azureclient

import (
	"github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/authorization/armauthorization/v2"
)

type RoleAssignment struct {
	PrincipalID string
	RoleID      string
}

type RoleDefinition struct {
	ID          string
	Name        string
	Permissions []*armauthorization.Permission
}

type Subscription struct {
	ID             string
	SubscriptionID string
	TenantID       string
	Policy         map[string][]string
}

type ManagementGroup struct {
	ID          string
	Type        string
	Name        string
	DisplayName string
	Policy      map[string][]string
}

type ResourceGroup struct {
	Id           string
	Location     string
	ManagedBy    string
	Tags         map[string]*string
	Name         string
	Type         string
	Policy       map[string][]string
	Subscription string
}

type Group struct {
	Name    string
	Id      string
	Members []User
}

type SqlServer struct {
	Location      string
	Tags          map[string]*string
	ID            string
	Kind          string
	Name          string
	Type          string
	Policy        map[string][]string
	ResourceGroup string
	Subscription  string
}

type LocationAssignment struct {
	ID                  *string
	Name                *string
	RegionalDisplayName *string
}

type User struct {
	ID       string
	Name     string
	UserType string
}

type DiscoveryResult struct {
	ManagementGroups map[string]ManagementGroup
	Subscriptions    map[string]Subscription
	ResourceGroups   map[string]ResourceGroup
	Users            map[string]User
	Groups           map[string]Group
	Roles            map[string]RoleDefinition
	Instances        map[string]SqlServer
	InstanceToUsers  map[string][]string
}
