package client

import (
	"context"
	"encoding/json"
	"fmt"
	"os"

	"go.uber.org/zap"
)

type MockFactory struct {
	MockGCPClient
}

func (factory *MockFactory) MakeClient(ctx context.Context, config *ClientConfig) (GCPClientInterface, error) {
	// Read gcpSqlUser.json
	gcpSqlUserData, err := os.ReadFile("../test/gcpSqlUser.json")
	if err != nil {
		fmt.Println("Error occurred while reading gcpSqlUser file ", err)
	}
	var gcpSqlUserList map[string][]GCPSQLUserDetails
	err = json.Unmarshal(gcpSqlUserData, &gcpSqlUserList)
	if err != nil {
		fmt.Println("Error occurred while unmashaling GCPSQLUserDetails ", err)
	}
	factory.GcpSqlList = gcpSqlUserList

	// Load test data for user list in oraganization
	userFileData, err := os.ReadFile("../test/ListUsersInOrganization.json")
	if err != nil {
		fmt.Println("Error occurred while reading ListUsersInOrganization.json file ", err)
	}
	var usersDetails map[string]GCPUserDetails
	err = json.Unmarshal(userFileData, &usersDetails)
	if err != nil {
		fmt.Println("Error occurred while unmashaling UsersDetails ", err)
	}
	factory.Users = usersDetails

	// Load test data for group list in oraganization
	groupFileData, err := os.ReadFile("../test/ListGroupsInOrganization.json")
	if err != nil {
		fmt.Println("Error occurred while reading ListGroupsInOrganization.json file ", err)
	}
	var groupListDetails map[string]GCPGroupDetails
	err = json.Unmarshal(groupFileData, &groupListDetails)
	if err != nil {
		fmt.Println("Error occurred while unmashaling groupListDetails ", err)
	}
	factory.Groups = groupListDetails

	// Load test data for folder list in oraganization
	folderFileData, err := os.ReadFile("../test/ListFoldersInOrganization.json")
	if err != nil {
		fmt.Println("Error occurred while reading ListFoldersInOrganization.json file ", err)
	}
	var folderDetails map[string]GCPFolderDetails
	err = json.Unmarshal(folderFileData, &folderDetails)
	if err != nil {
		fmt.Println("Error occurred while unmashaling folderDetails ", err)
	}
	factory.Folders = folderDetails

	// Load test data for organization policy
	orgPolicyData, err := os.ReadFile("../test/ListOrganizationPolicy.json")
	if err != nil {
		fmt.Println("Error occurred while reading ListOrganizationPolicy.json file ", err)
	}
	var orgPolicy GCPPolicy
	err = json.Unmarshal(orgPolicyData, &orgPolicy)
	if err != nil {
		fmt.Println("Error occurred while unmashaling orgPolicy ", err)
	}
	factory.OraganizationPolicy = &orgPolicy

	// Load test data for ListProjectsInFolder
	listProjectsInFolderData, err := os.ReadFile("../test/ListProjectsInFolder.json")
	if err != nil {
		fmt.Println("Error occurred while reading ListProjectsInFolder.json file ", err)
	}
	var listProjectsInFolder map[string][]GCPProjectDetails
	err = json.Unmarshal(listProjectsInFolderData, &listProjectsInFolder)
	if err != nil {
		fmt.Println("Error occurred while unmashaling listProjectsInFolder  ", err)
	}
	factory.FolderToProjects = listProjectsInFolder

	// Load test data for ListProjectsInInstance
	listProjectsInInstanceData, err := os.ReadFile("../test/ListProjectInstanceDetails.json")
	if err != nil {
		fmt.Println("Error occurred while reading ListProjectInstanceDetails.json file ", err)
	}
	var listProjectsInInstance map[string]*ListProjectInstanceDetailsResponse
	err = json.Unmarshal(listProjectsInInstanceData, &listProjectsInInstance)
	if err != nil {
		fmt.Println("Error occurred while unmashaling listProjectsInInstance  ", err)
	}
	factory.InstanceDetail = listProjectsInInstance

	// Load test data for ListServiceAccount
	listServiceAccountData, err := os.ReadFile("../test/ListServiceAccounts.json")
	if err != nil {
		fmt.Println("Error occurred while reading ListServiceAccounts.json file ", err)
	}
	var serviceAccount map[string]map[string]GCPServiceAccountDetails
	err = json.Unmarshal(listServiceAccountData, &serviceAccount)
	if err != nil {
		fmt.Println("Error occurred while unmashaling ListServiceAccounts  ", err)
	}
	factory.ServiceAccounts = serviceAccount
	return &factory.MockGCPClient, nil
}

type MockGCPClient struct {
	// discovery data
	GCPSQLInstances                 []GCPSQLInstanceDetails                        // List of instances
	Users                           map[string]GCPUserDetails                      // User Email to User Details
	Groups                          map[string]GCPGroupDetails                     // Group Email to Group Details
	ServiceAccounts                 map[string]map[string]GCPServiceAccountDetails // Service Account Email to Service Account Details
	Roles                           map[string]GCPRole                             // Role name to Role Details
	Folders                         map[string]GCPFolderDetails                    // Folder Number to Folder Details
	FolderToProjects                map[string][]GCPProjectDetails                 // Folder Number to list of projects
	GCPSQLInstanceToUsers           map[string]map[string][]string                 // Instance ID to User Email to list of roles
	GCPSQLInstanceToGroups          map[string]map[string][]string                 // Instance ID to Group Email to list of roles
	GCPSQLInstanceToServiceAccounts map[string]map[string][]string                 // Instance ID to Service Account Email to list of roles
	// extra data
	ProjectIdToPolicy          map[string]*GCPPolicy
	FolderIdToPolicy           map[string]*GCPPolicy
	ProjectIdToSQLInstanceList map[string][]GCPSQLInstanceDetails
	InstanceIdToUserDetails    map[string][]GCPSQLUserDetails
	ProjectIdToExcessRoles     map[string][]ExcessRole
	InstanceDetail             map[string]*ListProjectInstanceDetailsResponse
	GcpSqlList                 map[string][]GCPSQLUserDetails
	OraganizationPolicy        *GCPPolicy
	// config
	config ClientConfig
	//logging
	logger *zap.Logger
}

func (client *MockGCPClient) CheckConnection(ctx context.Context) error {
	return nil
}

func (client *MockGCPClient) ListFoldersInOrganization(ctx context.Context, pagination *PaginationFilter) (map[string]GCPFolderDetails, error) {
	return client.Folders, nil
}

func (client *MockGCPClient) ListProjectsInFolder(ctx context.Context, folder string, pagination *PaginationFilter) ([]GCPProjectDetails, error) {
	return client.FolderToProjects[folder], nil
}

func (client *MockGCPClient) ListUsersInOrganization(ctx context.Context, pagination *PaginationFilter) (map[string]GCPUserDetails, error) {
	return client.Users, nil
}

func (client *MockGCPClient) ListGroupsInOrganization(ctx context.Context, pagination *PaginationFilter) (map[string]GCPGroupDetails, error) {
	return client.Groups, nil
}

func (client *MockGCPClient) CheckPermission(_ context.Context) error {
	return nil
}

func (client *MockGCPClient) ListRoles(ctx context.Context) ([]GCPRole, error) {
	ret := []GCPRole{}
	for _, r := range client.Roles {
		ret = append(ret, r)
	}
	return ret, nil
}

func (client *MockGCPClient) ListProjectPolicy(ctx context.Context, project string) (*GCPPolicy, error) {
	return client.ProjectIdToPolicy[project], nil
}

func (client *MockGCPClient) ListGCPSQLInstances(ctx context.Context, projectId string, pagination *PaginationFilter) ([]GCPSQLInstanceDetails, error) {
	return client.ProjectIdToSQLInstanceList[projectId], nil
}

func (client *MockGCPClient) ListGCPSQLUsers(ctx context.Context, projectId string, pagination *PaginationFilter) (map[string][]GCPSQLUserDetails, error) {
	ret := map[string][]GCPSQLUserDetails{}
	instances := client.ProjectIdToSQLInstanceList[projectId]
	for _, instance := range instances {
		ret[instance.Id] = client.InstanceIdToUserDetails[instance.Id]
	}
	return ret, nil
}

func (client *MockGCPClient) ListFolderPolicy(ctx context.Context, folder string) (*GCPPolicy, error) {
	return client.FolderIdToPolicy[folder], nil
}

func (client *MockGCPClient) ListProjectExcessRoles(ctx context.Context, project string) ([]ExcessRole, error) {
	return client.ProjectIdToExcessRoles[project], nil
}

func (client *MockGCPClient) ListOrganizationPolicy(ctx context.Context) (*GCPPolicy, error) {

	return client.OraganizationPolicy, nil

}

func (client *MockGCPClient) ListServiceAccounts(ctx context.Context, projectId string) (map[string]GCPServiceAccountDetails, error) {
	return client.ServiceAccounts[projectId], nil
}

func (client *MockGCPClient) ListProjectInstanceDetails(ctx context.Context, parentPolicy *GCPPolicy, project string, pagination *PaginationFilter) (*ListProjectInstanceDetailsResponse, error) {
	return client.InstanceDetail[project], nil
}
func (client *MockGCPClient) ListGCPSQLInstanceUsers(ctx context.Context, instanceId, projectId string) ([]GCPSQLUserDetails, error) {
	return client.GcpSqlList[instanceId], nil
}
func (client *MockGCPClient) Run(ctx context.Context, pagination DiscoveryPaginationFilter) (*GcpSqlDiscoveryResult, error) {
	res := new(GcpSqlDiscoveryResult)
	res.GCPSQLInstanceToGroups = make(map[string]map[string][]string)
	res.GCPSQLInstanceToUsers = make(map[string]map[string][]string)
	res.GCPSQLInstanceToServiceAccounts = make(map[string]map[string][]string)
	res.Roles = make(map[string]GCPRole)
	res.ServiceAccounts = make(map[string]GCPServiceAccountDetails)
	// Get root resources
	users, err := client.ListUsersInOrganization(ctx, pagination.UserPagination)
	if err != nil {
		return nil, err
	}
	res.Users = users
	groups, err := client.ListGroupsInOrganization(ctx, pagination.GroupPagination)
	if err != nil {
		return nil, err
	}
	res.Groups = groups
	folders, err := client.ListFoldersInOrganization(ctx, pagination.FolderPagination)
	if err != nil {
		return nil, err
	}
	res.Folders = folders

	// Get organization policy to use to inherit roles downwards
	orgpolicy, err := client.ListOrganizationPolicy(ctx)
	if err != nil {
		return nil, err
	}

	folders[OrganizationPrefix+client.config.Organization] = GCPFolderDetails{
		Name:   OrganizationPrefix + client.config.Organization,
		Policy: orgpolicy,
	}

	folderToProjects := map[string][]GCPProjectDetails{}
	sqlInstanceUserList := map[string][]GCPSQLUserDetails{}
	for _, folder := range folders {
		projectList, err := client.ListProjectsInFolder(ctx, folder.Name, pagination.ProjectPagination)
		if err != nil {
			client.logger.Debug("Error occurred while listing projects in folder " + err.Error())
			continue
		}
		folderToProjects[folder.Name] = projectList
		mergePolicyResponse(folder.Policy, orgpolicy)
		for _, project := range projectList {
			serviceAccs, err := client.ListServiceAccounts(ctx, project.Id)
			if err != nil {
				return nil, err
			}
			for account, details := range serviceAccs {
				res.ServiceAccounts[account] = details
			}
			details, err := client.ListProjectInstanceDetails(ctx, folder.Policy, project.Id, pagination.InstancePagination)
			if err != nil {
				return nil, err
			}
			// merge discovered instances and associations to the discovery data
			res.GCPSQLInstances = append(res.GCPSQLInstances, details.Instances...)
			for k, v := range details.GCPSQLInstanceToUsers {
				res.GCPSQLInstanceToUsers[k] = v
			}
			for k, v := range details.GCPSQLInstanceToGroups {
				res.GCPSQLInstanceToGroups[k] = v
			}
			for k, v := range details.GCPSQLInstanceToServiceAccounts {
				res.GCPSQLInstanceToServiceAccounts[k] = v
			}
			for _, instance := range details.Instances {
				users, err := client.ListGCPSQLInstanceUsers(ctx, instance.Id, project.Id)
				if err != nil {
					return nil, err
				}
				users = removeDuplicateUser(users, res, instance.Name)
				sqlInstanceUserList[instance.Name] = users
			}
			for k, v := range details.Roles {
				if _, ok := res.Roles[k]; !ok {
					if !ok {
						res.Roles[k] = v
					}
				}
			}
		}
	}
	res.FolderToProjects = folderToProjects
	res.GCPSqlUser = sqlInstanceUserList
	return res, nil
}
