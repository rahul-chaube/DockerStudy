package client

import (
	"context"
)

type GCPClientInterface interface {
	CheckConnection(ctx context.Context) error
	ListFoldersInOrganization(ctx context.Context, pagination *PaginationFilter) (map[string]GCPFolderDetails, error)
	ListProjectsInFolder(ctx context.Context, folder string, pagination *PaginationFilter) ([]GCPProjectDetails, error)
	ListUsersInOrganization(ctx context.Context, pagination *PaginationFilter) (map[string]GCPUserDetails, error)
	ListGroupsInOrganization(ctx context.Context, pagination *PaginationFilter) (map[string]GCPGroupDetails, error)
	CheckPermission(context.Context) error
	ListProjectPolicy(ctx context.Context, project string) (*GCPPolicy, error)
	ListGCPSQLInstances(ctx context.Context, projectId string, pagination *PaginationFilter) ([]GCPSQLInstanceDetails, error)
	ListGCPSQLUsers(ctx context.Context, projectId string, pagination *PaginationFilter) (map[string][]GCPSQLUserDetails, error)
	Run(ctx context.Context, pagination DiscoveryPaginationFilter) (*GcpSqlDiscoveryResult, error)
	ListFolderPolicy(ctx context.Context, folder string) (*GCPPolicy, error)
	ListProjectExcessRoles(ctx context.Context, project string) ([]ExcessRole, error)
	ListGCPSQLInstanceUsers(ctx context.Context, instanceId, projectId string) ([]GCPSQLUserDetails, error)
}
