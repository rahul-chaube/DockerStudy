package azureclient

import (
	"context"
	"errors"

	"github.com/Azure/azure-sdk-for-go/sdk/azidentity"
	"github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/authorization/armauthorization/v2"
	"github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/managementgroups/armmanagementgroups"
	"github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/resources/armresources"
	"github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/resources/armsubscriptions"
	"github.com/Azure/azure-sdk-for-go/services/graphrbac/1.6/graphrbac"
	"github.com/Azure/go-autorest/autorest"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/cognitoidentity"
	"go.uber.org/zap"
)

type AzureConnectionManager struct {
	// TODO: fields to manage clients maybe
}

type ClientConfig struct {
	DeveloperProvider string      // AWS Cognito Developer Provider Name
	Developer         string      // AWS Cognito Developer ID
	Tenant            string      // Tenant ID
	Pool              string      // AWS Cognito Pool ID
	Client            string      // Managed identity Client ID
	Subscription      string      // Azure subscription ID
	Region            string      // AWS Region
	Logger            *zap.Logger // (Optional) Logger
}

func checkConfig(config *ClientConfig) error {
	if len(config.DeveloperProvider) == 0 {
		return ErrNoDeveloperProvider
	}
	if len(config.Developer) == 0 {
		return ErrNoDeveloper
	}
	if len(config.Pool) == 0 {
		return ErrNoPool
	}
	if len(config.Tenant) == 0 {
		return ErrNoTenant
	}
	if len(config.Client) == 0 {
		return ErrNoClient
	}
	if len(config.Region) == 0 {
		return ErrNoRegion
	}
	return nil
}

func (m *AzureConnectionManager) MakeClient(ctx context.Context, cfg *ClientConfig) (*AzureClient, error) {
	client := new(AzureClient)
	var err error
	if err = checkConfig(cfg); err != nil {
		return nil, err
	}
	client.Config = *cfg
	awscfg, err := config.LoadDefaultConfig(context.TODO())
	if err != nil {
		return nil, errors.New("error loading aws config: " + err.Error())
	}

	client.cognitoIdentityClient = cognitoidentity.New(cognitoidentity.Options{
		Region:      cfg.Region,
		Credentials: awscfg.Credentials,
	})
	client.azClientAssertionCredential, err = azidentity.NewClientAssertionCredential(cfg.Tenant, cfg.Client, client.getAssertion, nil)
	if err != nil {
		return nil, errors.New("error creating aws credential: " + err.Error())
	}

	clientFactory, err := armauthorization.NewClientFactory(client.Config.Subscription, client.azClientAssertionCredential, nil)
	if err != nil {
		return nil, errors.New("error creating azure auth client factory: " + err.Error())
	}
	client.roleAssignmentsClient = clientFactory.NewRoleAssignmentsClient()
	client.roleDefinitionsCLient = clientFactory.NewRoleDefinitionsClient()

	subclient, err := armsubscriptions.NewClient(client.azClientAssertionCredential, nil)
	if err != nil {
		return nil, errors.New("error creating subscriptions client: " + err.Error())
	}

	client.subscriptionsClient = subclient

	rgClientFactory, err := armresources.NewClientFactory(client.Config.Subscription, client.azClientAssertionCredential, nil)
	if err != nil {
		return nil, errors.New("error creating resource group client factory: " + err.Error())
	}

	client.resourceGroupClient = rgClientFactory.NewResourceGroupsClient()

	usersclient := graphrbac.NewUsersClient(client.Config.Tenant)

	userauth := new(Authenticator)
	userauth.Cred = client.azClientAssertionCredential
	userauth.Scope = GraphDefaultScope
	userauth.Tenant = cfg.Tenant

	usersclient.Authorizer = autorest.NewBearerAuthorizer(userauth)

	client.usersclient = &usersclient

	groupauth := new(Authenticator)
	groupauth.Cred = client.azClientAssertionCredential
	groupauth.Scope = ManagementDefaultScope
	groupauth.Tenant = cfg.Tenant

	armClient, err := armmanagementgroups.NewClientFactory(client.azClientAssertionCredential, nil)
	if err != nil {
		return nil, errors.New("error creating azure arm mamangement client factory: " + err.Error())
	}
	client.armmanagementClient = armClient.NewClient()

	// managementGroupClient := managementgroups.NewClient()
	// managementGroupClient.Authorizer = autorest.NewBearerAuthorizer(groupauth)

	// client.managementGroupClient = &managementGroupClient

	groupclient := graphrbac.NewGroupsClient(client.Config.Tenant)
	groupclient.Authorizer = autorest.NewBearerAuthorizer(userauth)
	client.groupClient = &groupclient

	if cfg.Logger != nil {
		client.logger = cfg.Logger
	} else {
		client.logger = zap.L()
	}
	return client, nil
}
