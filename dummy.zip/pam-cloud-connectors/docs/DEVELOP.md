# Usage

## Run

After following the procedures defined in docs/aws/setup/README.MD and docs/gcp/setup/README.md you can gather all the required information to start a client.

Using ```make run-test``` will compress and upload the irectory to the remote server with the address defined in the ./IPADDRESS file using the user defined in the ./TESTINGUSER file, source the environment containing the information needed to configure the client and run ```make test```

## Creating a client

Requirements for creating a client:

- Organization ID (Environment Variable: TEST_ORAGANIZATION_NUMBER)
- Project Number (the project that was used to define the service account) (Environment Variable: TEST_PROJECT_NUMBER)
- Workload Identity Federation Pool (Environment Variable: TEST_POOL)
- Workload Identity Federation Provider (Environment Variable: TEST_PROVIDER)
- Service account Email (Environment Variable: TEST_SERVICE_ACCOUNT)

```go
	manager := new(GCPConnectionManager)
	config := &ClientConfig{
		Organization:        TEST_ORAGANIZATION_NUMBER,
		Project:             TEST_PROJECT_NUMBER,
		Pool:                TEST_POOL,
		Provider:            TEST_PROVIDER,
		ServiceAccountEmail: TEST_SERVICE_ACCOUNT,
	}
	ctx := context.Background()
	client, err := manager.MakeClient(ctx, config)
	if err != nil {
		// handle error
	}
```

## Checking Connection

The connection check aims to be as close to the GetSelf used for checking the AWS connection. It gets the service account used from the config and tries to get it through the API

```go
    if err := client.CheckConnection(ctx); err != nil {
		// handle error
	}
```

## Discover Resources

### Pagination

By the Google documentation:
```json
"maxResults": {
	       "default": "100",
	       "description": "Maximum number of results to return.",
	       "format": "int32",
	       "location": "query",
	       "maximum": "500",
	       "minimum": "1",
	       "type": "integer"
	     }
```

### Listing Users

```go
    users, err := client.ListUsersInOrganization(ctx)
	if err != nil {
		// handle error
	}
```

### Listing Folders

```go
    folders, err := client.ListFoldersInOrganization(ctx)
	if err != nil {
		// handle error
	}
```

### Listing Projects in Folder

```go
    projects, err := client.ListProjectsInFolder(ctx, folder.Name)
	if err != nil {
		// handle error
	}
```

### Listing Folder IAM Bindings

```go
    policy, err := client.ListFolderPolicy(ctx, folder.Name)
    if err != nil {
        // handle error
    }
```

### Listing Project IAM Bindings

```go
    policy, err := client.ListProjectPolicy(ctx, project.Id)
	if err != nil {
		// handle error
	}
```

### Get Role Details

Role details contain the role along with the permissions it contains

```go
    perms, err := client.GetRole(ctx, binding.Role)
	if err != nil {
		t.Fatal(err)
	}
```

### Get Excess roles

Excess roles contain a role and the member that holds it and are identified by Recommender if it has already run on a resource.

```go
    xroles, err := client.ListProjectExcessRoles(ctx, project.Id)
	if err != nil {
		// handle error
	}
```

Refer to client/connection_test.go for an example of using the client methods mentioned here to list all the resources on an organization