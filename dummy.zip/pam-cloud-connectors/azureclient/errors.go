package azureclient

import "errors"

var (
	// Configuration Errors
	ErrNoDeveloper         = errors.New("missing developer id")
	ErrNoDeveloperProvider = errors.New("missing developer provider name")
	ErrNoPool              = errors.New("missing pool")
	ErrNoTenant            = errors.New("missing tenant")
	ErrNoClient            = errors.New("missing client id")
	ErrNoRegion            = errors.New("missing region")

	ErrNoFolderAccess = errors.New("folder access forbiden")
)
