package client

import (
	"context"
	"testing"
)

func TestGCPConnectionManager_MakeClient(t *testing.T) {

	type args struct {
		ctx    context.Context
		config *ClientConfig
	}
	tests := []struct {
		name    string
		m       *GCPConnectionManager
		args    args
		wantErr bool
	}{
		{
			name: "Create Client ",
			args: args{
				ctx:    context.Background(),
				config: &config,
			},
			wantErr: false,
		},
		{
			name: "Invalid Key",
			args: args{
				ctx:    context.Background(),
				config: &ClientConfig{},
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			m := &GCPConnectionManager{}
			_, err := m.MakeClient(tt.args.ctx, tt.args.config)
			if (err != nil) != tt.wantErr {
				t.Errorf("GCPConnectionManager.MakeClient() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}
