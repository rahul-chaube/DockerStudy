package client

import (
	"context"
	"encoding/json"
	"errors"

	recommender "cloud.google.com/go/recommender/apiv1"
	resourcemanager "cloud.google.com/go/resourcemanager/apiv3"
	"cloud.google.com/go/resourcemanager/apiv3/resourcemanagerpb"
	"go.uber.org/zap"
	admin "google.golang.org/api/admin/directory/v1"
	"google.golang.org/api/iam/v1"
	"google.golang.org/api/option"
	sqladmin "google.golang.org/api/sqladmin/v1"
)

type GCPConnectionManager struct {
	// TODO: fields to manage clients maybe
}

type ClientConfig struct {
	Organization              string      // Organization Numebr
	Project                   string      // Project Number
	Pool                      string      // Pool ID
	Provider                  string      // Provider ID
	ServiceAccountEmail       string      // Service Account Email
	domain                    string      // Organization domain (needed to list user and group details, automatically discovered)
	connectionConfig          []byte      // JSON config
	credentials               Credentials // Credentials are derived from ConnectionConfig
	MaxUserPageSize           int64       // Page size used if none is defined on method call
	MaxFolderPageSize         int64
	MaxGroupPageSize          int64
	MaxInstancePageSize       int64
	MaxServiceAccountPageSize int64
	MaxProjectPageSize        int64
	Logger                    *zap.Logger // (Optional) Logger
}

func checkConfig(config *ClientConfig) error {
	if len(config.Organization) == 0 {
		return ErrNoOrganization
	}
	if len(config.Project) == 0 {
		return ErrNoProject
	}
	if len(config.Pool) == 0 {
		return ErrNoProvider
	}
	if len(config.Provider) == 0 {
		return ErrNoServiceAccount
	}
	if len(config.ServiceAccountEmail) == 0 {
		return ErrNoServiceAccount
	}
	if config.MaxUserPageSize == 0 {
		config.MaxUserPageSize = 100 // apply google default
	}
	if config.MaxFolderPageSize == 0 {
		config.MaxFolderPageSize = 100 // apply google default
	}
	if config.MaxGroupPageSize == 0 {
		config.MaxGroupPageSize = 100 // apply google default
	}
	if config.MaxInstancePageSize == 0 {
		config.MaxInstancePageSize = 100 // apply google default
	}
	return nil
}

func (m *GCPConnectionManager) MakeClient(ctx context.Context, config *ClientConfig) (GCPClientInterface, error) {
	var err error
	if err = checkConfig(config); err != nil {
		return nil, err
	}
	config.credentials = NewCredentials(config.Project, config.Pool, config.Provider, config.ServiceAccountEmail)
	config.connectionConfig, err = json.Marshal(config.credentials)
	if err != nil {
		return nil, err
	}
	client := new(GCPClient)
	client.config = *config
	creds := option.WithCredentialsJSON(config.connectionConfig)

	projclient, err := resourcemanager.NewProjectsClient(ctx, creds)
	if err != nil {
		return nil, errors.New("error creating projects client: " + err.Error())
	}
	client.projectsClient = projclient

	foldersClient, err := resourcemanager.NewFoldersClient(ctx, creds)
	if err != nil {
		return nil, errors.New("error creating folders client: " + err.Error())
	}
	client.foldersClient = foldersClient

	orgsclient, err := resourcemanager.NewOrganizationsClient(ctx, creds)
	if err != nil {
		return nil, errors.New("error creating organizations client: " + err.Error())
	}
	client.orgsClient = orgsclient

	req := &resourcemanagerpb.GetOrganizationRequest{
		Name: "organizations/" + client.config.Organization,
	}

	org, err := client.orgsClient.GetOrganization(ctx, req)
	if err != nil {
		return nil, errors.New("error getting organization details: " + err.Error())
	}

	client.config.domain = org.DisplayName

	adminService, err := admin.NewService(ctx, creds)
	if err != nil {
		return nil, errors.New("error creating admin client:" + err.Error())
	}
	client.adminClient = adminService

	// Create the Google Cloud SQL service.
	sqlservice, err := sqladmin.NewService(ctx, creds)
	if err != nil {
		return nil, errors.New("error sql service client:" + err.Error())
	}
	client.sqlService = sqlservice

	if config.Logger != nil {
		client.logger = config.Logger
	} else {
		client.logger = zap.L()
	}

	iamService, err := iam.NewService(ctx, creds)
	if err != nil {
		return nil, errors.New("error creating admin client:" + err.Error())
	}
	client.iamService = iamService

	c, err := recommender.NewClient(ctx, creds)
	if err != nil {
		return nil, errors.New("error creating recommender client: " + err.Error())
	}

	client.recommenderClient = c

	return client, err
}
