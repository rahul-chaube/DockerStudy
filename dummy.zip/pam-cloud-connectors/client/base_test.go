package client

import (
	"context"
	"log"
	"os"
	"testing"

	"github.com/caarlos0/env"
	"github.com/joho/godotenv"
)

var cfgTest ConfigTest
var client GCPClientInterface
var ctx context.Context
var config ClientConfig

type ConfigTest struct {
	SETTINGS_FILE       string `env:"SETTINGSFILE"`
	ORGANIZATION_NUMBER string `env:"TEST_ORAGANIZATION_NUMBER"`
	PROJECT_NUMBER      string `env:"TEST_PROJECT_NUMBER"`
	PROVIDER            string `env:"TEST_PROVIDER"`
	POOL                string `env:"TEST_POOL"`
	SERVICE_ACCOUNT     string `env:"TEST_SERVICE_ACCOUNT"`
}

func TestMain(m *testing.M) {
	if err := loadTestEnviromentVariables(); err != nil {
		log.Fatal("error reading settings file:", err)
	}

	if err := mockClient(); err != nil {
		log.Fatal("error creating mock client:", err)
	}

	exitVal := m.Run()
	os.Exit(exitVal)
}

func loadTestEnviromentVariables() error {
	//loads and checks (if there is not env file logs error)
	if err := godotenv.Load("../.env.test"); err != nil {
		return err
	}

	//parse the configs
	if err := env.Parse(&cfgTest); err != nil {
		return err
	}
	return nil
}

func mockClient() error {

	manager := new(GCPConnectionManager)
	config = ClientConfig{
		Organization:        cfgTest.ORGANIZATION_NUMBER,
		Project:             cfgTest.PROJECT_NUMBER,
		Pool:                cfgTest.POOL,
		Provider:            cfgTest.PROVIDER,
		ServiceAccountEmail: cfgTest.SERVICE_ACCOUNT,
	}

	ctx = context.Background()
	var err error

	if client, err = manager.MakeClient(ctx, &config); err != nil {
		return err
	}

	return nil
}
