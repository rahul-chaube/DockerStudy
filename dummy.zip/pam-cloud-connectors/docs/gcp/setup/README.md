# Resource Setup

## Service account

### Google Console

1. Go to the Create service account page https://console.cloud.google.com/iam-admin/serviceaccounts/create
2. Select a Google Cloud project.
3. Enter a service account name to display in the Google Cloud console. The Google Cloud console generates a service account ID based on this name. Edit the ID if necessary. You cannot change the ID later.
4. Optional: Enter a description of the service account.
5. On the Roles page (https://console.cloud.google.com/iam-admin/roles) Create a new role with the following permissions:
- cloudsql.instances.get
- cloudsql.instances.list
- cloudsql.users.get
- cloudsql.users.list
- iam.roles.get
- iam.serviceAccounts.get
- iam.serviceAccounts.getAccessToken
- iam.serviceAccounts.getOpenIdToken
- iam.serviceAccounts.implicitDelegation
- iam.serviceAccounts.list
- iam.serviceAccounts.signBlob
- iam.serviceAccounts.signJwt
- recommender.iamPolicyRecommendations.list
- resourcemanager.folders.get
- resourcemanager.folders.getIamPolicy
- resourcemanager.folders.list
- resourcemanager.organizations.get
- resourcemanager.organizations.getIamPolicy
- resourcemanager.projects.get
- resourcemanager.projects.getIamPolicy
- resourcemanager.projects.list
6. On the Cloud Resource Manager Page (https://console.cloud.google.com/cloud-resource-manager) click on the organization you want to provide the service account access to, click on permissions on the top right, Add Principal, paste the service account email, and assign the principal the role you created above.
7. On the Admin console create a custome role (https://support.google.com/a/answer/2406043) with the view permissions of the group admin (namely “View user profiles and your organizational structure”)
8. Assign the role to the service account


### CLI

This yaml definition is used to create the role.
```yaml
title: ROLE_TITLE
description: ROLE_DESCRIPTION
stage: LAUNCH_STAGE
includedPermissions:
- PERMISSION_1
- PERMISSION_2
```

```bash
# Create service account
gcloud iam service-accounts create SA_NAME \
    --description="DESCRIPTION" \
    --display-name="DISPLAY_NAME"

# Create custom role
gcloud iam roles create ROLE_ID--organization=ORGANIZATION_ID \
    --file=YAML_FILE_PATH

# Add Workload Identity User role
gcloud projects add-iam-policy-binding PROJECT_ID \
    --member="serviceAccount:SA_NAME@PROJECT_ID.iam.gserviceaccount.com" \
    --role="roles/yourRoleID"
```

## Workload Identity Pool And Provider

### Google Console

1. Go to the Create Identity pool page https://console.cloud.google.com/iam-admin/workload-identity-pools/create and click on Add Provider > New Pool
2. Enter a pool name
3. Optional: Enter a description
4. Select a provider
5. Add a provider name
6. Add the connecting AWS Account ID
7. Save
8. On the pool Page click on Grant Access
9. Select the service account you created
10. To grant access:
    - For a specific instance: Select the "subject" attribute name and add the ARN of the relevant AWS resource in the following format arn:aws:sts::AWS_ACCOUNT_ID:assumed-role/ASSIGNED_ROLE_NAME/INSTANCE_ID
    - For a role: Select the "aws_role" attribute name and add the ARN of the relevant AWS resource in the following format arn:aws:sts::AWS_ACCOUNT_ID:assumed-role/ASSIGNED_ROLE_NAME (for instances the role should be the role assigned to the instance, for a cluster it should be the role assigned to the worker group)
11. On the service account page, on Permissions, add the relevant roles (mentioned above) on the principal that was added when you Granted Access to the service account. It is in the format: principal://iam.googleapis.com/projects/PROJECT/locations/global/workloadIdentityPools/POOL_ID/subject/SUBJECT

### CLI

```bash
# Create Workload Identity Pool
gcloud iam workload-identity-pools create POOL_ID \
    --location="global" \
    --description="DESCRIPTION" \
    --display-name="DISPLAY_NAME"


# Create Workload Identity Provider
gcloud iam workload-identity-pools providers create-aws --location="global" --workload-identity-pool="my-workload-identity-pool" --display-name="My workload pool provider" --description="My workload pool provider description" --disabled --attribute-mapping="google.subject=assertion.arn" --attribute-condition="true" --account-id=AWSACCOUNTID

# Allow the external workload to impersonate the service account
## For a specific instance
gcloud iam service-accounts add-iam-policy-binding SERVICE_ACCOUNT_EMAIL \
    --role=roles/iam.workloadIdentityUser \
    --member="principal://iam.googleapis.com/projects/PROJECT_NUMBER/locations/global/workloadIdentityPools/POOL_ID/subject/arn:aws:sts::AWS_ACCOUNT_ID:assumed-role/ASSIGNED_ROLE_NAME/INSTANCE_ID"
## For a cluster role
gcloud iam service-accounts add-iam-policy-binding SERVICE_ACCOUNT_EMAIL \
    --role=roles/iam.workloadIdentityUser \
    --member="principal://iam.googleapis.com/projects/PROJECT_NUMBER/locations/global/workloadIdentityPools/POOL_ID/attribute.aws_role/arn:aws:sts::AWS_ACCOUNT_ID:assumed-role/ASSIGNED_ROLE_NAME"

gcloud iam workload-identity-pools create-cred-config \
    projects/PROJECT_NUMBER/locations/global/workloadIdentityPools/POOL_ID/providers/PROVIDER_ID \
    --service-account=SERVICE_ACCOUNT_EMAIL \
    --service-account-token-lifetime-seconds=SERVICE_ACCOUNT_TOKEN_LIFETIME \
    --aws \
    --output-file=FILEPATH.json
```

## Providing access to the organization

### Google console

1. Go to the Cloud Resource Manager page https://console.cloud.google.com/cloud-resource-manager
2. Click on the organization you want to provide access to
3. Click on Add Principal
4. Add the name of your service account
5. Add the service account permissions listed above

### CLI

