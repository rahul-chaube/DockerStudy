package azureclient

import (
	"context"
	"log"
	"testing"
)

func TestAzureClient_ListUsers(t *testing.T) {
	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name    string
		args    args
		want    []Group
		wantErr bool
	}{
		{
			name: " TestAzureClient_ListUsers",
			args: args{
				ctx: ctx,
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			users, err := client.ListUsers(context.Background())
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.ListUsers() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			t.Log(users)
		})
	}
}

func TestAzureClient_Discover(t *testing.T) {
	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name    string
		args    args
		want    []Group
		wantErr bool
	}{
		{
			name: " TestAzureClient_Discover",
			args: args{
				ctx: ctx,
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			discovery, err := Discover(context.Background(), client)
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.ListUsers() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			t.Log(discovery)
		})
	}
}

func TestAzureClient_ListSubscriptions(t *testing.T) {
	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name    string
		args    args
		want    []Group
		wantErr bool
	}{
		{
			name: " TestAzureClient_ListSubscriptions",
			args: args{
				ctx: ctx,
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			sub, err := client.ListSubscriptions(context.Background())
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.ListSubscriptions() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			t.Log(sub)
		})
	}
}

func TestAzureClient_ListManagementGroupDescendentInfo(t *testing.T) {
	type args struct {
		ctx     context.Context
		groupID string
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		{
			name:    "testing positive test case",
			args:    args{ctx: context.Background(), groupID: "test-management-group-2"},
			wantErr: false,
		},
		{
			name:    "Invalid groupID",
			args:    args{ctx: context.Background(), groupID: "test-management-group-2_test"},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {

			dsdInfo, err := client.ListManagementGroupDescendentInfo(tt.args.ctx, tt.args.groupID)
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.GetListManagementGroupDescendentInfo() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			t.Log(dsdInfo)
		})
	}
}

func TestGetSubscription(t *testing.T) {
	type args struct {
		ctx            context.Context
		SubscriptionId string
	}
	tests := []struct {
		name    string
		args    args
		want    []Subscription
		wantErr bool
	}{
		{
			name:    "Valid subscriptionID",
			args:    args{ctx: context.Background(), SubscriptionId: cfg.Subscription},
			wantErr: false,
		},
		{
			name:    "Invalid subscriptionID",
			args:    args{ctx: context.Background(), SubscriptionId: "Invalid"},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			sub, err := client.GetSubscription(tt.args.ctx, tt.args.SubscriptionId)
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.GetSubscription() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			t.Log(sub)
		})
	}
}

func TestListLocationsForSubscriptionId(t *testing.T) {
	type args struct {
		ctx            context.Context
		SubscriptionId string
	}
	tests := []struct {
		name    string
		args    args
		want    []LocationAssignment
		wantErr bool
	}{
		{
			name:    "Valid subscriptionID",
			args:    args{ctx: context.Background(), SubscriptionId: cfg.Subscription},
			wantErr: false,
		},
		{
			name:    "Invalid subscriptionID",
			args:    args{ctx: context.Background(), SubscriptionId: "Invalid"},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			locations, err := client.ListLocationsForSubscriptionId(tt.args.ctx, tt.args.SubscriptionId)
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.ListLocationsForSubscriptionId() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			t.Log(locations)
		})
	}
}

func TestGetResourceGroup(t *testing.T) {
	type args struct {
		ctx          context.Context
		ResourceName string
	}
	tests := []struct {
		name    string
		args    args
		want    ResourceGroup
		wantErr bool
	}{
		{
			name:    "Valid resource group ",
			args:    args{ctx: context.Background(), ResourceName: cfgTest.AZURE_RESOURCE_GROUP},
			wantErr: false,
		},
		{
			name:    "Invalid resource group ",
			args:    args{ctx: context.Background(), ResourceName: "invalid"},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			rg, err := client.GetResourceGroup(tt.args.ctx, tt.args.ResourceName)
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.GetResourceGroup() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			t.Log(rg)
		})
	}
}

func TestAzureClient_GetSqlServerList(t *testing.T) {
	type args struct {
		ctx            context.Context
		ResourceName   string
		SubscriptionId string
	}
	tests := []struct {
		name    string
		args    args
		want    []SqlServer
		wantErr bool
	}{
		{
			name:    "Valid resource group ",
			args:    args{ctx: context.Background(), ResourceName: cfgTest.AZURE_RESOURCE_GROUP, SubscriptionId: cfg.Subscription},
			wantErr: false,
		},
		{
			name:    "Invalid resource group ",
			args:    args{ctx: context.Background(), ResourceName: "invalid", SubscriptionId: client.Config.Subscription},
			wantErr: true,
		},
		{
			name:    "Invalid subscriptionID",
			args:    args{ctx: context.Background(), ResourceName: "test-resource-group-2", SubscriptionId: "Invalid"},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			serverLists, err := client.GetSqlServerList(tt.args.ctx, tt.args.SubscriptionId, tt.args.ResourceName)
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.GetSqlServerList() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if tt.args.ResourceName == cfgTest.AZURE_RESOURCE_GROUP {

				for _, server := range cfgTest.TEST_AZURE_LIST_OF_SERVER {
					_, isExist := serverLists["/subscriptions/534b95e6-7061-4dd7-92a7-c09c6be3d9d6/resourceGroups/test_level_0/providers/Microsoft.Sql/servers/myazuresqlserver11"]
					if !isExist {
						t.Errorf("AzureClient.GetSqlServerList() not matched %s", server)
						break
					}
				}
			}
			t.Log(serverLists)
		})
	}
}

func TestAzureClient_ListGroupss(t *testing.T) {
	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name    string
		args    args
		want    []Group
		wantErr bool
	}{
		{
			name: " TestAzureClient_ListGroupss- List group",
			args: args{
				ctx: ctx,
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := client.ListGroups(tt.args.ctx)
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.ListGroupss() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			t.Log(got)
		})
	}
}

func TestAzureClient_ListGroupsMember(t *testing.T) {

	type args struct {
		ctx           context.Context
		groupObjectId string
	}
	tests := []struct {
		name    string
		args    args
		want    []User
		wantErr bool
	}{
		{
			name: "Valid Group",
			args: args{
				ctx:           context.Background(),
				groupObjectId: "a34498e7-f7fc-44d3-9b19-febf41bf3e95",
			},
			wantErr: false,
		},
		{
			name: "Valid Group",
			args: args{
				ctx:           context.Background(),
				groupObjectId: "7919058f-7d22-49b6-9b7d-bdbd6e8718fd",
			},
			wantErr: false,
		},
		{
			name: "InValid Group",
			args: args{
				ctx:           context.Background(),
				groupObjectId: "Invalid Group",
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := client.ListGroupMembers(tt.args.ctx, tt.args.groupObjectId)
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.ListGroupsMember() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			t.Log(got)
		})
	}
}

func TestAzureClient_ListRolesForResourceGroup(t *testing.T) {
	type args struct {
		ctx     context.Context
		groupID string
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		{
			name: "ListRolesForResourceGroup - Positive test case",
			args: args{
				ctx:     context.Background(),
				groupID: "test-resource-group-2",
			},
			wantErr: false,
		},
		{
			name: "ListRolesForResourceGroup - Negative test case",
			args: args{
				ctx:     context.Background(),
				groupID: "Invalid group id",
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := client.ListRolesForResourceGroup(tt.args.ctx, tt.args.groupID)
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.ListRolesForResourceGroup() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func TestAzureClient_ListRolesForSQLInstance(t *testing.T) {
	type args struct {
		ctx               context.Context
		resourceGroupName string
		sqlServerNameName string
	}
	tests := []struct {
		name    string
		args    args
		want    map[string][]string
		wantErr bool
	}{
		{
			name: "List SqlServer Roles",
			args: args{
				ctx:               context.Background(),
				resourceGroupName: "test-resource-group-2",
				sqlServerNameName: "test-server-mysql-1",
			},
			wantErr: false,
		},
		{
			name: "Invalid SqlServer test case ",
			args: args{
				ctx:               context.Background(),
				resourceGroupName: "test-resource-group-2",
				sqlServerNameName: "invalid",
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {

			_, err := client.ListRolesForSQLInstance(tt.args.ctx, tt.args.resourceGroupName, tt.args.sqlServerNameName)
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.ListRolesForSQLInstance() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func TestAzureClient_GetRoleDefinitions(t *testing.T) {

	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name    string
		args    args
		want    map[string]RoleDefinition
		wantErr bool
	}{
		{
			name: "Positive case ",
			args: args{
				ctx: context.Background(),
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := client.GetRoleDefinitions(tt.args.ctx)
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.GetRoleDefinitions() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func TestAzureClient_ListRolesForSubscription(t *testing.T) {
	type args struct {
		ctx          context.Context
		subscription string
	}
	tests := []struct {
		name    string
		args    args
		want    map[string][]string
		wantErr bool
	}{
		{
			name: "Valid case ",
			args: args{
				ctx:          context.Background(),
				subscription: cfg.Subscription,
			},
			wantErr: false,
		},
		{
			name: "Invalid case",
			args: args{
				ctx:          context.Background(),
				subscription: "Invalid",
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			roles, err := client.ListRolesForSubscription(tt.args.ctx, SubscriptionPrefix+client.Config.Subscription)
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.ListRolesForSubscription() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			log.Println("roles: ", roles)

		})
	}
}

func TestAzureClient_ListRolesForManagementGroup(t *testing.T) {
	type args struct {
		ctx             context.Context
		managementgroup string
	}
	tests := []struct {
		name    string
		args    args
		want    map[string][]string
		wantErr bool
	}{
		{
			name: "Positive test case",
			args: args{
				ctx:             ctx,
				managementgroup: "providers/Microsoft.Management/managementGroups/test-management-group-2",
			},
		},
		{
			name: "Positive test case 1",
			args: args{
				ctx:             ctx,
				managementgroup: "/providers/Microsoft.Management/managementGroups/test-management-group-1",
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := client.ListRolesForManagementGroup(tt.args.ctx, tt.args.managementgroup)
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.ListRolesForManagementGroup() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			t.Log(got)
		})
	}
}

func TestAzureClient_ListManagementGroups(t *testing.T) {
	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name    string
		args    args
		want    []ManagementGroup
		wantErr bool
	}{
		{
			name: "Positive case",
			args: args{
				ctx: context.Background(),
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := client.ListManagementGroups(tt.args.ctx)
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.ListManagementGroups() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			t.Log(got)
		})
	}
}

func TestAzureClient_CheckConnection(t *testing.T) {
	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		{
			name: "Positive case",
			args: args{
				ctx: context.Background(),
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := client.CheckConnection(tt.args.ctx)
			if (err != nil) != tt.wantErr {
				t.Errorf("AzureClient.CheckConnection() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}
