package client

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"reflect"
	"testing"

	"go.uber.org/zap"
)

func TestMockGCPClient_Run(t *testing.T) {
	mockClient := MockFactory{}
	mockClient.logger = zap.L()
	if err := loadTestEnviromentVariables(); err != nil {
		t.Fatal("error reading settings file:", err)
	}
	mockClient.config = ClientConfig{
		Organization:        cfgTest.ORGANIZATION_NUMBER,
		Project:             cfgTest.PROJECT_NUMBER,
		Pool:                cfgTest.POOL,
		Provider:            cfgTest.PROVIDER,
		ServiceAccountEmail: cfgTest.SERVICE_ACCOUNT,
	}

	result, err := loadExpectedResult()
	if err != nil {
		t.Error(err)
		return
	}
	client, err := mockClient.MakeClient(context.Background(), &ClientConfig{})
	if err != nil {
		return
	}
	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name    string
		args    args
		want    *GcpSqlDiscoveryResult
		wantErr bool
	}{
		{
			name: "Positive Test case",
			args: args{
				ctx: context.Background(),
			},
			want:    &result,
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := client.Run(tt.args.ctx, DiscoveryPaginationFilter{})
			if (err != nil) != tt.wantErr {
				t.Errorf("MockGCPClient.Run() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("MockGCPClient.Run() = error occured while compareing object ")
			}
		})
	}
}
func loadExpectedResult() (GcpSqlDiscoveryResult, error) {
	resultData, err := os.ReadFile("../test/expectedResult.json")
	if err != nil {
		fmt.Println("Error occure while reading expectedResult file ", err)
		return GcpSqlDiscoveryResult{}, err
	}
	var result GcpSqlDiscoveryResult
	err = json.Unmarshal(resultData, &result)
	if err != nil {
		fmt.Println("Error occure while unmashaling expectedResult ", err)
		return GcpSqlDiscoveryResult{}, err
	}
	return result, nil
}
