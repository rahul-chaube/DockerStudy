package client

import "errors"

var (
	// Configuration Errors
	ErrNoOrganization   = errors.New("missing organization")
	ErrNoProject        = errors.New("missing project")
	ErrNoPool           = errors.New("missing pool")
	ErrNoProvider       = errors.New("missing provider")
	ErrNoServiceAccount = errors.New("missing serice account")

	ErrNoFolderAccess = errors.New("folder access forbiden")
)
