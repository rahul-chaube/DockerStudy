package client

import (
	"context"
	"errors"
	"strings"

	"go.uber.org/zap"

	recommender "cloud.google.com/go/recommender/apiv1"
	"cloud.google.com/go/recommender/apiv1/recommenderpb"

	resourcemanager "cloud.google.com/go/resourcemanager/apiv3"
	"cloud.google.com/go/resourcemanager/apiv3/resourcemanagerpb"
	admin "google.golang.org/api/admin/directory/v1"
	iam "google.golang.org/api/iam/v1"
	"google.golang.org/api/iterator"

	sqladmin "google.golang.org/api/sqladmin/v1"

	iampb "cloud.google.com/go/iam/apiv1/iampb"
)

var (
	neededFolderPermissions  = []string{}
	neededProjectPermissions = []string{}

	neededOragnizationPermissions = []string{
		"cloudsql.instances.get",
		"cloudsql.users.get",
		"cloudsql.users.list",
		"iam.roles.get",
		"iam.serviceAccounts.get",
		"iam.serviceAccounts.getAccessToken",
		"cloudsql.instances.list",
		"iam.serviceAccounts.getOpenIdToken",
		"iam.serviceAccounts.implicitDelegation",
		"iam.serviceAccounts.list",
		"iam.serviceAccounts.signBlob",
		"iam.serviceAccounts.signJwt",
		"recommender.iamPolicyRecommendations.list",
		"resourcemanager.folders.get",
		"resourcemanager.folders.getIamPolicy",
		"resourcemanager.folders.list",
		"resourcemanager.organizations.get",
		"resourcemanager.organizations.getIamPolicy",
		"resourcemanager.projects.get",
		"resourcemanager.projects.getIamPolicy",
		"resourcemanager.projects.list",
	}
)

type GCPClient struct {
	config            ClientConfig
	projectsClient    *resourcemanager.ProjectsClient
	orgsClient        *resourcemanager.OrganizationsClient
	foldersClient     *resourcemanager.FoldersClient
	adminClient       *admin.Service
	sqlService        *sqladmin.Service
	iamService        *iam.Service
	recommenderClient *recommender.Client
	logger            *zap.Logger
}

// CheckConnection gets the service account we are working as to ensure we are authenticated
func (client *GCPClient) CheckConnection(ctx context.Context) error {
	_, err := client.iamService.Projects.ServiceAccounts.Get(ProjectServiceAccountPrefix + client.config.credentials.ServiceAccount()).Context(ctx).Do()
	if err != nil {
		return err
	}
	client.logger.Debug("connected successfuly as: " + client.config.credentials.ServiceAccount())
	return nil
}

// List service accounts defined in a give project
func (client *GCPClient) ListServiceAccounts(ctx context.Context, project string) (map[string]GCPServiceAccountDetails, error) {
	ret := map[string]GCPServiceAccountDetails{}
	accs, err := client.iamService.Projects.ServiceAccounts.List(ProjectPrefix + project).Context(ctx).Do()
	if err != nil {
		return nil, err
	}
	for _, acc := range accs.Accounts {
		ret[acc.Email] = GCPServiceAccountDetails{
			Id:          acc.UniqueId,
			Name:        acc.Name,
			Email:       acc.Email,
			Disabled:    acc.Disabled,
			ProjectId:   acc.ProjectId,
			DisplayName: acc.DisplayName,
		}
	}
	return ret, nil
}

// CheckPermission checks that we have the needed permissions to access all the resources we need to go through
func (client *GCPClient) CheckPermission(ctx context.Context) error {
	if err := client.checkOraganizationAccess(ctx); err != nil {
		return err
	}
	return nil
}

func (client *GCPClient) checkFolderAccess(ctx context.Context, folderName string) error {
	req := &iampb.TestIamPermissionsRequest{
		Resource:    "folders/" + folderName,
		Permissions: neededFolderPermissions,
	}

	_, err := client.foldersClient.TestIamPermissions(ctx, req)
	return err
}

func (client *GCPClient) checkProjectAccess(ctx context.Context) error {
	req := &iampb.TestIamPermissionsRequest{
		Resource:    "projects/" + client.config.Project,
		Permissions: neededProjectPermissions,
	}
	_, err := client.projectsClient.TestIamPermissions(ctx, req)
	return err
}

func (client *GCPClient) checkOraganizationAccess(ctx context.Context) error {
	req := &iampb.TestIamPermissionsRequest{
		Resource:    "organizations/" + client.config.Organization,
		Permissions: neededOragnizationPermissions,
	}

	_, err := client.orgsClient.TestIamPermissions(ctx, req)
	return err
}

func (client *GCPClient) ListFoldersInOrganization(ctx context.Context, pagination *PaginationFilter) (map[string]GCPFolderDetails, error) {
	ret := map[string]GCPFolderDetails{}
	foldersreq := &resourcemanagerpb.ListFoldersRequest{
		Parent: OrganizationPrefix + client.config.Organization,
	}
	it := client.foldersClient.ListFolders(ctx, foldersreq)
	pageinfo := it.PageInfo()
	if pagination == nil || pagination.Count == 0 {
		pageinfo.MaxSize = int(client.config.MaxFolderPageSize)
	} else {
		pageinfo.MaxSize = int(pagination.Count)
	}
	for {
		resp, err := it.Next()
		if err == iterator.Done {
			break
		}
		if err != nil {
			return nil, err
		}
		folderpolicy, err := client.ListFolderPolicy(ctx, resp.Name)
		if err != nil {
			return nil, err
		}
		ret[resp.Name] = GCPFolderDetails{
			Name:        resp.Name,
			DisplayName: resp.DisplayName,
			Policy:      folderpolicy,
			Parent:      resp.Parent,
			State:       int32(resp.State),
		}
		inner, err := client.listFoldersInFolder(ctx, resp.Name, pagination)
		if err != nil {
			return nil, err
		}
		for _, innerfolder := range inner {
			innerfolderpolicy, err := client.ListFolderPolicy(ctx, innerfolder.Name)
			if err != nil {
				return nil, err
			}
			mergePolicyResponse(innerfolderpolicy, folderpolicy)
			ret[innerfolder.Name] = GCPFolderDetails{
				Name:        innerfolder.Name,
				DisplayName: innerfolder.DisplayName,
				Policy:      innerfolderpolicy,
				Parent:      innerfolder.Parent,
				State:       int32(innerfolder.State),
			}
		}
	}
	return ret, nil
}

func (client *GCPClient) listFoldersInFolder(ctx context.Context, folder string, pagination *PaginationFilter) ([]GCPFolderDetails, error) {
	ret := []GCPFolderDetails{}
	foldersreq := &resourcemanagerpb.ListFoldersRequest{
		Parent: folder,
	}
	it := client.foldersClient.ListFolders(ctx, foldersreq)
	pageinfo := it.PageInfo()
	if pagination == nil || pagination.Count == 0 {
		pageinfo.MaxSize = int(client.config.MaxFolderPageSize)
	} else {
		pageinfo.MaxSize = int(pagination.Count)
	}
	for {
		resp, err := it.Next()
		if err == iterator.Done {
			break
		}
		if err != nil {
			return nil, err
		}

		ret = append(ret, GCPFolderDetails{
			Name:        resp.GetName(),
			DisplayName: resp.DisplayName,
			Parent:      resp.Parent,
			State:       int32(resp.State),
		})

		inner, err := client.listFoldersInFolder(ctx, resp.Name, pagination)
		if err != nil {
			return nil, err
		}
		ret = append(ret, inner...)
	}
	return ret, nil
}

func (client *GCPClient) ListProjectsInFolder(ctx context.Context, folder string, pagination *PaginationFilter) ([]GCPProjectDetails, error) {
	req := &resourcemanagerpb.ListProjectsRequest{
		Parent: folder,
	}
	return client.ListProjects(ctx, req, pagination)
}

// ListProjectsInOrganization lists projects that are not assigned to any folder
func (client *GCPClient) ListProjectsInOrganization(ctx context.Context, pagination *PaginationFilter) ([]GCPProjectDetails, error) {
	req := &resourcemanagerpb.ListProjectsRequest{
		Parent: OrganizationPrefix + client.config.Organization,
	}
	return client.ListProjects(ctx, req, pagination)
}

func (client *GCPClient) ListProjects(ctx context.Context, req *resourcemanagerpb.ListProjectsRequest, pagination *PaginationFilter) ([]GCPProjectDetails, error) {
	ret := []GCPProjectDetails{}

	it := client.projectsClient.ListProjects(ctx, req)
	pageinfo := it.PageInfo()
	if pagination == nil || pagination.Count == 0 {
		pageinfo.MaxSize = int(client.config.MaxProjectPageSize)
	} else {
		pageinfo.MaxSize = int(pagination.Count)
	}
	for {
		resp, err := it.Next()
		if err == iterator.Done {
			break
		}
		if err != nil {
			return nil, err
		}
		ret = append(ret, GCPProjectDetails{
			Id:   resp.ProjectId,
			Name: resp.Name,
		})
	}
	return ret, nil
}

func (client *GCPClient) ListProjectPolicy(ctx context.Context, project string) (*GCPPolicy, error) {
	req := &iampb.GetIamPolicyRequest{
		Resource: ProjectPrefix + project,
	}

	policy, err := client.projectsClient.GetIamPolicy(ctx, req)
	if err != nil {
		return nil, err
	}

	return client.analyzeIAMPolicy(ctx, policy)
}

func (client *GCPClient) analyzeIAMPolicy(ctx context.Context, policy *iampb.Policy) (*GCPPolicy, error) {
	ret := new(GCPPolicy)
	usermap := map[string][]string{}
	groupmap := map[string][]string{}
	serviceAccmap := map[string][]string{}
	projectroles := map[string]GCPRole{}
	for _, conf := range policy.Bindings {
		if _, ok := projectroles[conf.Role]; !ok {
			role, err := client.GetRole(ctx, conf.Role)
			if err != nil {
				return nil, err
			}
			projectroles[role.Name] = role
		}
		for _, member := range conf.Members {
			switch {
			case strings.HasPrefix(member, UserPrefix):
				mail := strings.TrimPrefix(member, UserPrefix)
				if roles, ok := usermap[mail]; ok {
					usermap[mail] = append(roles, conf.Role)
				} else {
					usermap[mail] = []string{conf.Role}
				}
			case strings.HasPrefix(member, GroupPrefix):
				mail := strings.TrimPrefix(member, GroupPrefix)
				if roles, ok := groupmap[mail]; ok {
					groupmap[mail] = append(roles, conf.Role)
				} else {
					groupmap[mail] = []string{conf.Role}
				}
			case strings.HasPrefix(member, ServiceAccountPrefix):
				mail := strings.TrimPrefix(member, ServiceAccountPrefix)
				if roles, ok := serviceAccmap[mail]; ok {
					serviceAccmap[mail] = append(roles, conf.Role)
				} else {
					serviceAccmap[mail] = []string{conf.Role}
				}
			default:
				// there is a domain: prefix got to look on how to handle that
				client.logger.Debug("unknown member type for " + member)
			}
		}
	}
	ret.GroupPolicy = groupmap
	ret.UserPolicy = usermap
	ret.ServiceAccountPolicy = serviceAccmap
	ret.Roles = projectroles
	return ret, nil

}

func (client *GCPClient) ListOrganizationPolicy(ctx context.Context) (*GCPPolicy, error) {
	req := &iampb.GetIamPolicyRequest{
		Resource: OrganizationPrefix + client.config.Organization,
	}
	policy, err := client.orgsClient.GetIamPolicy(ctx, req)
	if err != nil {
		return nil, err
	}
	return client.analyzeIAMPolicy(ctx, policy)
}

func (client *GCPClient) ListFolderPolicy(ctx context.Context, folder string) (*GCPPolicy, error) {
	req := &iampb.GetIamPolicyRequest{
		Resource: folder,
	}
	policy, err := client.foldersClient.GetIamPolicy(ctx, req)
	if err != nil {
		return nil, err
	}
	return client.analyzeIAMPolicy(ctx, policy)
}

func (client *GCPClient) ListUsersInOrganization(ctx context.Context, pagination *PaginationFilter) (map[string]GCPUserDetails, error) {
	ret := map[string]GCPUserDetails{}
	pageSize := int64(0)
	if pagination == nil || pagination.Count == 0 {
		pageSize = client.config.MaxUserPageSize
	} else {
		pageSize = pagination.Count
	}
	err := client.adminClient.Users.List().Domain(client.config.domain).MaxResults(pageSize).Pages(ctx, func(users *admin.Users) error {
		for _, user := range users.Users {
			ret[user.PrimaryEmail] = GCPUserDetails{
				Id:               user.Id,
				Name:             user.Name.DisplayName,
				FullName:         user.Name.FullName,
				Email:            user.PrimaryEmail,
				isAdmin:          user.IsAdmin,
				IsDelegatedAdmin: user.IsDelegatedAdmin,
				Suspended:        user.Suspended,
				OrgUnitPath:      user.OrgUnitPath,
			}
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return ret, nil
}

func (client *GCPClient) ListGroupsInOrganization(ctx context.Context, pagination *PaginationFilter) (map[string]GCPGroupDetails, error) {
	ret := map[string]GCPGroupDetails{}
	pageSize := int64(0)
	if pagination == nil || pagination.Count == 0 {
		pageSize = client.config.MaxGroupPageSize
	} else {
		pageSize = pagination.Count
	}
	err := client.adminClient.Groups.List().Domain(client.config.domain).MaxResults(pageSize).Pages(ctx, func(groups *admin.Groups) error {
		for _, grp := range groups.Groups {
			details := GCPGroupDetails{
				Id:                 grp.Id,
				Name:               grp.Name,
				Email:              grp.Email,
				AdminCreated:       grp.AdminCreated,
				Description:        grp.Description,
				Aliases:            grp.Aliases,
				DirectMembersCount: grp.DirectMembersCount,
				Etag:               grp.Etag,
				NonEditableAliases: grp.NonEditableAliases,
			}
			members, err := client.adminClient.Members.List(details.Id).Context(ctx).Do()
			if err != nil {
				return err
			}
			for _, member := range members.Members {
				details.Members = append(details.Members, member.Email)
			}
			ret[details.Email] = details
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return ret, nil
}

// RolesList return list of roles and basic details about roles
func (client *GCPClient) GetRole(ctx context.Context, roleName string) (GCPRole, error) {
	retrole := GCPRole{}
	req, err := client.iamService.Roles.Get(roleName).Context(ctx).Do()
	if err != nil {
		return retrole, err
	}
	retrole = GCPRole{
		Name:                req.Name,
		Description:         req.Description,
		Stage:               req.Stage,
		ETag:                req.Etag,
		IncludedPermissions: req.IncludedPermissions,
		Deleted:             req.Deleted,
	}
	return retrole, nil
}

// ListGCPSQLInstances lists all SQL instances in a project
func (client *GCPClient) ListGCPSQLInstances(ctx context.Context, projectId string, pagination *PaginationFilter) ([]GCPSQLInstanceDetails, error) {
	ret := []GCPSQLInstanceDetails{}
	pageSize := int64(0)
	if pagination == nil || pagination.Count == 0 {
		pageSize = client.config.MaxInstancePageSize
	} else {
		pageSize = pagination.Count
	}
	// List instances for the project ID.
	err := client.sqlService.Instances.List(projectId).MaxResults(pageSize).Pages(ctx, func(instances *sqladmin.InstancesListResponse) error {
		for _, instance := range instances.Items {
			ret = append(ret, GCPSQLInstanceDetails{
				Id:                       instance.Name,
				Name:                     instance.Name,
				Region:                   instance.Region,
				Project:                  instance.Project,
				DatabaseInstalledVersion: instance.DatabaseInstalledVersion,
				GCEZone:                  instance.GceZone,
				MaxDiskSize:              instance.MaxDiskSize,
				SecondaryGceZone:         instance.SecondaryGceZone,
				SelfLink:                 instance.SelfLink,
				SqlNetworkArchitecture:   instance.SqlNetworkArchitecture,
				State:                    instance.State,
			})
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return ret, nil
}

// ListGCPSQLInstanceUsers lists all users with their respective roles for an SQL instance
func (client *GCPClient) ListGCPSQLInstanceUsers(ctx context.Context, instanceId, projectId string) ([]GCPSQLUserDetails, error) {
	ret := []GCPSQLUserDetails{}

	users, err := client.sqlService.Users.List(projectId, instanceId).Context(ctx).Do()
	if err != nil {
		return nil, err
	}

	for _, user := range users.Items {
		userDetails := GCPSQLUserDetails{
			Name:    user.Name,
			Host:    user.Host,
			Type:    user.Type,
			Project: user.Project,
		}
		if user.SqlserverUserDetails != nil {
			userDetails.Roles = user.SqlserverUserDetails.ServerRoles
		}
		ret = append(ret, userDetails)
	}

	return ret, nil
}

// ListGCPSQLInstanceUsers lists all users with their respective roles for an project
func (client *GCPClient) ListGCPSQLUsers(ctx context.Context, projectId string, pagination *PaginationFilter) (map[string][]GCPSQLUserDetails, error) {
	ret := map[string][]GCPSQLUserDetails{}

	instances, err := client.ListGCPSQLInstances(ctx, projectId, pagination)
	if err != nil {
		return nil, err
	}

	for _, instance := range instances {
		instanceUsers, err := client.ListGCPSQLInstanceUsers(ctx, instance.Id, projectId)
		if err != nil {
			return nil, err
		}
		ret[instance.Id] = instanceUsers
	}

	return ret, nil
}

func (client *GCPClient) ListProjectExcessRoles(ctx context.Context, project string) ([]ExcessRole, error) {
	ret := []ExcessRole{}
	req := &recommenderpb.ListRecommendationsRequest{
		Parent: "projects/" + project + "/locations/global/recommenders/google.iam.policy.Recommender",
	}
	it := client.recommenderClient.ListRecommendations(ctx, req)
	for {
		resp, err := it.Next()
		if err == iterator.Done {
			break
		}
		if err != nil {
			return nil, err
		}

		recmap := resp.Content.Overview.AsMap()

		member, ok := recmap["member"].(string)
		if !ok {
			continue
		}

		excessRole, ok := recmap["removedRole"].(string)
		if !ok {
			continue
		}

		ret = append(ret, ExcessRole{
			Member: member,
			Role:   excessRole,
		})
	}

	return ret, nil
}

// ListProjectInstanceDetails lists instances along with the users that have access to them with their respective roles
func (client *GCPClient) ListProjectInstanceDetails(ctx context.Context, parentPolicy *GCPPolicy, project string, pagination *PaginationFilter) (*ListProjectInstanceDetailsResponse, error) {
	resp := new(ListProjectInstanceDetailsResponse)
	resp.GCPSQLInstanceToGroups = make(map[string]map[string][]string)
	resp.GCPSQLInstanceToUsers = make(map[string]map[string][]string)
	resp.GCPSQLInstanceToServiceAccounts = make(map[string]map[string][]string)
	// Get instances
	instances, err := client.ListGCPSQLInstances(ctx, project, pagination)
	if err != nil {
		return nil, err
	}
	resp.Instances = instances

	// Get project roles for users
	policy, err := client.ListProjectPolicy(ctx, project)
	if err != nil {
		return nil, err
	}

	mergePolicyResponse(policy, parentPolicy)

	resp.Roles = policy.Roles

	for _, instance := range instances {
		instancegroups, err := cleanUnauthorizedMembers(policy.GroupPolicy, policy.Roles)
		if err != nil {
			return nil, err
		}
		if len(instancegroups) > 0 {
			resp.GCPSQLInstanceToGroups[instance.Id] = instancegroups
		}
		instanceServiceAccs, err := cleanUnauthorizedMembers(policy.ServiceAccountPolicy, policy.Roles)
		if err != nil {
			return nil, err
		}
		if len(instanceServiceAccs) > 0 {
			resp.GCPSQLInstanceToServiceAccounts[instance.Id] = instanceServiceAccs
		}
		instanceUsers, err := cleanUnauthorizedMembers(policy.UserPolicy, policy.Roles)
		if err != nil {
			return nil, err
		}
		if len(instanceUsers) > 0 {
			resp.GCPSQLInstanceToUsers[instance.Id] = instanceUsers
		}
	}
	return resp, nil
}

// cleanUnauthorizedMembers ensures that only users with the "cloudsql.instances.login" permission are listed when associating roles to instances
func cleanUnauthorizedMembers(membermap map[string][]string, discoveredroles map[string]GCPRole) (map[string][]string, error) {
	for member, roles := range membermap {
		found := false
		for _, role := range roles {
			gcprole, ok := discoveredroles[role]
			if !ok {
				return nil, errors.New("undiscovered role")
			}
			// iterate through role permissions
			for _, perm := range gcprole.IncludedPermissions {
				if perm == "cloudsql.instances.login" {
					found = true
					break
				}
			}
			if found {
				break
			}
		}
		if !found {
			delete(membermap, member)
		}
	}
	return membermap, nil
}

// Run discovers all needed data
func (client *GCPClient) Run(ctx context.Context, pagination DiscoveryPaginationFilter) (*GcpSqlDiscoveryResult, error) {
	res := new(GcpSqlDiscoveryResult)
	res.GCPSQLInstanceToGroups = make(map[string]map[string][]string)
	res.GCPSQLInstanceToUsers = make(map[string]map[string][]string)
	res.GCPSQLInstanceToServiceAccounts = make(map[string]map[string][]string)
	res.Roles = make(map[string]GCPRole)
	res.ServiceAccounts = make(map[string]GCPServiceAccountDetails)
	// Get root resources
	users, err := client.ListUsersInOrganization(ctx, pagination.UserPagination)
	if err != nil {
		return nil, err
	}
	res.Users = users
	groups, err := client.ListGroupsInOrganization(ctx, pagination.GroupPagination)
	if err != nil {
		return nil, err
	}
	res.Groups = groups
	folders, err := client.ListFoldersInOrganization(ctx, pagination.FolderPagination)
	if err != nil {
		return nil, err
	}
	res.Folders = folders

	// Get organization policy to use to inherit roles downwards
	orgpolicy, err := client.ListOrganizationPolicy(ctx)
	if err != nil {
		return nil, err
	}

	folders[OrganizationPrefix+client.config.Organization] = GCPFolderDetails{
		Name:   OrganizationPrefix + client.config.Organization,
		Policy: orgpolicy,
	}

	folderToProjects := map[string][]GCPProjectDetails{}
	sqlInstanceUserList := map[string][]GCPSQLUserDetails{}
	for _, folder := range folders {
		projectList, err := client.ListProjectsInFolder(ctx, folder.Name, pagination.ProjectPagination)
		if err != nil {
			client.logger.Debug("Error occure while listing projects in folder " + err.Error())
			continue
		}
		folderToProjects[folder.Name] = projectList
		mergePolicyResponse(folder.Policy, orgpolicy)
		for _, project := range projectList {
			serviceAccs, err := client.ListServiceAccounts(ctx, project.Id)
			if err != nil {
				return nil, err
			}
			for account, details := range serviceAccs {
				res.ServiceAccounts[account] = details
			}
			details, err := client.ListProjectInstanceDetails(ctx, folder.Policy, project.Id, pagination.InstancePagination)
			if err != nil {
				return nil, err
			}
			// merge discovered instances and associations to the discovery data
			res.GCPSQLInstances = append(res.GCPSQLInstances, details.Instances...)
			for k, v := range details.GCPSQLInstanceToUsers {
				res.GCPSQLInstanceToUsers[k] = v
			}
			for k, v := range details.GCPSQLInstanceToGroups {
				res.GCPSQLInstanceToGroups[k] = v
			}
			for k, v := range details.GCPSQLInstanceToServiceAccounts {
				res.GCPSQLInstanceToServiceAccounts[k] = v
			}
			for _, instance := range details.Instances {
				users, err := client.ListGCPSQLInstanceUsers(ctx, instance.Id, project.Id)
				if err != nil {
					return nil, err
				}
				users = removeDuplicateUser(users, res, instance.Name)
				sqlInstanceUserList[instance.Name] = users
			}
			for k, v := range details.Roles {
				if _, ok := res.Roles[k]; !ok {
					if !ok {
						res.Roles[k] = v
					}
				}
			}
		}
	}

	res.FolderToProjects = folderToProjects
	res.GCPSqlUser = sqlInstanceUserList
	return res, nil
}

// mergePolicyResponse is used to inherit permissions across levels
func mergePolicyResponse(receiver, target *GCPPolicy) {
	for tname, trole := range target.Roles {
		if _, ok := receiver.Roles[tname]; !ok {
			receiver.Roles[tname] = trole
		}
	}
	receiver.UserPolicy = mergePolicies(receiver.UserPolicy, target.UserPolicy)
	receiver.GroupPolicy = mergePolicies(receiver.GroupPolicy, target.GroupPolicy)
	receiver.ServiceAccountPolicy = mergePolicies(receiver.ServiceAccountPolicy, target.ServiceAccountPolicy)
}

// mergePolicies is used to merge maps of users and respective roles across levels
func mergePolicies(receiver, target map[string][]string) map[string][]string {
	for tmember, troles := range target {
		if rroles, ok := receiver[tmember]; ok {
			for _, role := range troles {
				found := false
				for _, rrole := range rroles {
					if role == rrole {
						found = true
						break
					}
				}
				if !found {
					rroles = append(rroles, role)
				}
			}
			receiver[tmember] = rroles
		} else {
			receiver[tmember] = troles
		}
	}
	return receiver
}

// removeDuplicateUser checks if a principal already exists in the list of principals having inherited access to that instance
// if it does not, it gets added to the appropriate list
func removeDuplicateUser(principals []GCPSQLUserDetails, res *GcpSqlDiscoveryResult,
	instananceName string) []GCPSQLUserDetails {
	gcpSqlUsers := []GCPSQLUserDetails{}
	uniqueUser := make(map[string]bool)
	var data map[string][]string
	for _, principal := range principals {
		found := false
		// check for the entity type
		switch principal.Type {
		case "CLOUD_IAM_SERVICE_ACCOUNT":
			data = res.GCPSQLInstanceToServiceAccounts[instananceName]
		case "CLOUD_IAM_GROUP":
			data = res.GCPSQLInstanceToGroups[instananceName]
		case "CLOUD_IAM_USER":
			data = res.GCPSQLInstanceToUsers[instananceName]
		default:
			gcpSqlUsers = append(gcpSqlUsers, principal)
			continue
		}
		// check if we already included that user in our instance access
		// list through the project level defined policy
		for key, _ := range data {
			if strings.HasPrefix(key, principal.Name) { // e.g. georgios.bourikas@okta.com has prefix georgios.bourikas
				found = true
				break
			}
		}
		// if the user/group/service account is not found on the existing access map,
		// this means that they do not have access on the project level but have
		// access to the instance only
		if !found {
			if _, ok := uniqueUser[principal.Name]; !ok {
				uniqueUser[principal.Name] = true
				gcpSqlUsers = append(gcpSqlUsers, principal)
				switch principal.Type {
				case "CLOUD_IAM_USER":
					if _, ok := res.GCPSQLInstanceToUsers[instananceName]; !ok {
						res.GCPSQLInstanceToUsers[instananceName] = make(map[string][]string)
					}
					res.GCPSQLInstanceToUsers[instananceName][principal.Name] =
						[]string{"cloudsql.instances.login"}
				case "CLOUD_IAM_SERVICE_ACCOUNT":
					if _, ok := res.GCPSQLInstanceToServiceAccounts[instananceName]; !ok {
						res.GCPSQLInstanceToServiceAccounts[instananceName] = make(map[string][]string)
					}
					res.GCPSQLInstanceToServiceAccounts[instananceName][principal.Name] =
						[]string{"cloudsql.instances.login"}
				case "CLOUD_IAM_GROUP":
					if _, ok := res.GCPSQLInstanceToGroups[instananceName]; !ok {
						res.GCPSQLInstanceToGroups[instananceName] = make(map[string][]string)
					}
					res.GCPSQLInstanceToGroups[instananceName][principal.Name] =
						[]string{"cloudsql.instances.login"}
				default:
					continue
				}
			}
		}
	}
	return gcpSqlUsers
}
