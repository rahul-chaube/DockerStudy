package main

import (
	"context"
	"log"

	"github.com/atko-pam/pam-cloud-connectors/client"
)

func main() {

	TEST_ORAGANIZATION_NUMBER := "1068859173740"

	TEST_PROJECT_NUMBER := "912592410639"

	TEST_POOL := "test-identity-pool"

	TEST_PROVIDER := "test-provider"

	TEST_SERVICE_ACCOUNT := "test-service-account-1@my-project-1-410616.iam.gserviceaccount.com"

	manager := new(client.GCPConnectionManager)
	config := &client.ClientConfig{
		Organization:        TEST_ORAGANIZATION_NUMBER,
		Project:             TEST_PROJECT_NUMBER,
		Pool:                TEST_POOL,
		Provider:            TEST_PROVIDER,
		ServiceAccountEmail: TEST_SERVICE_ACCOUNT,
	}
	ctx := context.Background()
	client, err := manager.MakeClient(ctx, config)
	if err != nil {
		log.Fatal("error making client", err)
	}
	if err := client.CheckConnection(ctx); err != nil {
		log.Fatal("error checking connection", err)
	}

	if err := client.CheckPermission(ctx); err != nil {
		log.Fatal("error checking permission", err)
	}
}
