package azureclient

import (
	"context"

	"github.com/Azure/azure-sdk-for-go/sdk/azcore"
	"github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/resources/armresources"
)

type AzureClientInterface interface {
	GetRoleDefinitions(ctx context.Context) ([]RoleDefinition, error)
	GetResourceGroup(ctx context.Context, groupID string) (*ResourceGroup, error)
	ListRolesForResourceGroup(ctx context.Context, groupID string) ([]RoleAssignment, error)
	ListResourceGroupsForSubscription(ctx context.Context, subscriptionId string, credential azcore.TokenCredential) ([]*armresources.ResourceGroup, error)
	GetSubscription(ctx context.Context, subscriptionId string) (*Subscription, error)
	ListSubscriptions(ctx context.Context) (map[string]Subscription, error)
	ListRolesForSQLInstance(ctx context.Context, groupName, resourceName string) (map[string][]string, error)
	ListRolesForSubscription(ctx context.Context, subscription string) (map[string][]string, error)
	GetSqlServerList(context.Context, string, string) ([]SqlServer, error)
	ListGroups(context.Context) ([]Group, error)
	ListGroupsMember(context.Context, string) ([]User, error)
}
