package azureclient

// Entity name prefixes
const (
	SubscriptionPrefix           = "subscriptions/"
	ServersResourceType          = "servers"
	SQLResourceProviderNamespace = "Microsoft.Sql"
)

// Configuration static strings
const (
	GraphDefaultScope      = "https://graph.windows.net/.default"
	ManagementDefaultScope = "https://management.core.windows.net/.default"
)
