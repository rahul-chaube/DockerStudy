package azureclient

import (
	"context"
	"log"
	"os"
	"testing"

	"github.com/caarlos0/env"
	"github.com/joho/godotenv"
	"go.uber.org/zap"
)

var cfgTest ConfigTest
var ctx context.Context
var cfg ClientConfig
var client *AzureClient

type ConfigTest struct {
	AZURE_CLIENT_ID           string   `env:"TEST_AZURE_CLIENT_ID"`
	AZURE_POOL_ID             string   `env:"TEST_AZURE_AWS_POOL_ID"`
	AZURE_REGION              string   `env:"TEST_AZURE_AWS_REGION"`
	AZURE_PROVIDER            string   `env:"TEST_AZURE_AWS_DEVELOPER_PROVIDER"`
	AZURE_TENANT              string   `env:"TEST_AZURE_TENANT_ID"`
	AZURE_DEVELOPER           string   `env:"TEST_AZURE_AWS_DEVELOPER"`
	AZURE_SUBSCRIPTION_ID     string   `env:"TEST_AZURE_SUBSCRIPTION_ID"`
	AZURE_RESOURCE_GROUP      string   `env:"TEST_AZURE_RESOURCE_GROUP"`
	TEST_AZURE_LIST_OF_SERVER []string `env:"TEST_AZURE_LIST_OF_SERVER"`
}

func TestMain(m *testing.M) {
	if err := loadTestEnviromentVariables(); err != nil {
		log.Fatal("error reading settings file:", err)
	}

	manager := new(AzureConnectionManager)
	cfg = ClientConfig{
		DeveloperProvider: cfgTest.AZURE_PROVIDER,
		Pool:              cfgTest.AZURE_POOL_ID,
		Client:            cfgTest.AZURE_CLIENT_ID,
		Region:            cfgTest.AZURE_REGION,
		Tenant:            cfgTest.AZURE_TENANT,
		Developer:         cfgTest.AZURE_DEVELOPER,
		Subscription:      cfgTest.AZURE_SUBSCRIPTION_ID,
		Logger:            &zap.Logger{},
	}

	ctx = context.Background()
	var err error

	if client, err = manager.MakeClient(ctx, &cfg); err != nil {
		log.Fatal("error making client:", err)
	}

	exitVal := m.Run()
	os.Exit(exitVal)
}

func loadTestEnviromentVariables() error {
	//loads and checks (if there is not env file logs error)
	if err := godotenv.Load("../.env.test"); err != nil {
		return err
	}

	//parse the configs
	if err := env.Parse(&cfgTest); err != nil {
		return err
	}
	return nil
}
