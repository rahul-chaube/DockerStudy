#!/bin/bash

export TEST_ORAGANIZATION_NUMBER="1068859173740"
export TEST_PROJECT_NUMBER="912592410639"
export TEST_POOL="test-identity-pool"
export TEST_PROVIDER="test-provider"
export TEST_SERVICE_ACCOUNT="test-service-account-1@my-project-1-410616.iam.gserviceaccount.com"
