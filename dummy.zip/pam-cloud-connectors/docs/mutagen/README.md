# Mutagen Setup

## Description

Mutagen helps to synchronize files between local environment and server instance

## Install

1. macOs and Linux: install mutagen using the first command (if needs to install the Homebrew follow the <[brew]>)
2. Create a new sync with SSH connection in the second example (follow the format)
3. To see the progress and watch some news syncs use the third example
4. The oficial documentation: <[mutagen.io]>

```console
brew install mutagen-io/mutagen/mutagen
```

```console
mutagen sync create --name=pam-connectors ~/Go/pam-cloud-connectors <user>@<ip>:~/pam-cloud-connectors 
```

```console
mutagen sync monitor
```

[mutagen.io]: https://mutagen.io/documentation/introduction
[brew]: ttps://brew.sh