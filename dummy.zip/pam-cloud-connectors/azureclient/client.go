package azureclient

import (
	"context"
	"errors"
	"fmt"
	"net/url"
	"strings"

	"github.com/Azure/azure-sdk-for-go/sdk/azcore/policy"
	"github.com/Azure/azure-sdk-for-go/sdk/azidentity"
	"github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/authorization/armauthorization/v2"
	"github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/resources/armresources"
	"github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/resources/armsubscriptions"
	"github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/sql/armsql"
	"github.com/Azure/azure-sdk-for-go/services/graphrbac/1.6/graphrbac"
	"github.com/aws/aws-sdk-go-v2/service/cognitoidentity"
	"go.uber.org/zap"

	"github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/managementgroups/armmanagementgroups"
)

type AzureClient struct {
	Config                      ClientConfig
	cognitoIdentityClient       *cognitoidentity.Client
	azClientAssertionCredential *azidentity.ClientAssertionCredential
	resourceGroupClient         *armresources.ResourceGroupsClient
	roleAssignmentsClient       *armauthorization.RoleAssignmentsClient
	roleDefinitionsCLient       *armauthorization.RoleDefinitionsClient
	subscriptionsClient         *armsubscriptions.Client
	serversClient               *armsql.ServersClient
	usersclient                 *graphrbac.UsersClient
	groupClient                 *graphrbac.GroupsClient
	logger                      *zap.Logger
	armmanagementClient         *armmanagementgroups.Client
}

// getAssertion gets an aws cognito token for the clients developer identity
func (client *AzureClient) getAssertion(ctx context.Context) (string, error) {
	awstoken, err := client.cognitoIdentityClient.GetOpenIdTokenForDeveloperIdentity(context.Background(), &cognitoidentity.GetOpenIdTokenForDeveloperIdentityInput{
		IdentityPoolId: &client.Config.Pool,
		Logins: map[string]string{
			client.Config.DeveloperProvider: client.Config.Developer,
		},
	})
	if err != nil {
		return "", err
	}
	return *awstoken.Token, nil
}

// Authenticator implements autorest adal.OAuthTokenProvider and holds the information needed to issue a token for a specified scope
type Authenticator struct {
	Tenant string
	Scope  string
	Cred   *azidentity.ClientAssertionCredential
}

func (client *Authenticator) OAuthToken() string {
	token, err := client.Cred.GetToken(context.Background(), policy.TokenRequestOptions{
		Scopes:   []string{client.Scope},
		TenantID: client.Tenant,
	})
	if err != nil {
		fmt.Println(" Error occured OAuthToken", err.Error())
		// client.logger.Error("error getting assertion credential token: " + err.Error())
		return ""
	}
	return url.QueryEscape(token.Token)
}

func (client *AzureClient) CheckConnection(ctx context.Context) error {
	_, err := client.GetSubscription(ctx, client.Config.Subscription)
	return err
}

// ListUsers gets list of users for the current tenant
func (client *AzureClient) ListUsers(ctx context.Context) (map[string]User, error) {
	users := map[string]User{}
	resp, err := client.usersclient.List(ctx, "", "")
	if err != nil {
		return nil, err
	}
	for _, u := range resp.Values() {
		users[*u.ObjectID] = User{
			ID:   *u.ObjectID,
			Name: *u.DisplayName,
		}
	}
	return users, err
}

func (client *AzureClient) GetResourceGroup(ctx context.Context, groupID string) (*ResourceGroup, error) {
	rg, err := client.resourceGroupClient.Get(context.Background(), groupID, nil)
	if err != nil {
		return nil, err
	}

	return &ResourceGroup{
		Id:       *rg.ID,
		Location: *rg.Location,
		Name:     *rg.Name,
		Type:     *rg.Type,
	}, nil
}

// List management groups for the authenticated user
func (client *AzureClient) ListManagementGroups(ctx context.Context) (map[string]ManagementGroup, error) {
	managementGroups := map[string]ManagementGroup{}

	pager := client.armmanagementClient.NewListPager(&armmanagementgroups.ClientListOptions{})
	for pager.More() {
		resp, err := pager.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		if resp.Value != nil {
			for _, val := range resp.Value {
				managementGroups[*val.ID] = ManagementGroup{
					ID:          *val.ID,
					Name:        *val.Name,
					DisplayName: *val.Properties.DisplayName,
					Type:        *val.Type,
				}
			}
		}
	}
	return managementGroups, nil
}

// Gets all the resource groups for a subscription
func (client *AzureClient) ListResourceGroupsForSubscription(ctx context.Context, subscriptionId string) (map[string]ResourceGroup, error) {
	// client has to be created per subscription because this is the level the "per subscription" scope gets applied in
	rgClient, err := armresources.NewResourceGroupsClient(client.Config.Subscription, client.azClientAssertionCredential, nil)
	if err != nil {
		return nil, errors.New("error creating resource group client for subscription" + client.Config.Subscription + ": " + err.Error())
	}
	pager := rgClient.NewListPager(nil)

	resourceGroups := make(map[string]ResourceGroup)
	for pager.More() {
		resp, err := pager.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		if resp.ResourceGroupListResult.Value != nil {
			for _, grp := range resp.Value {
				resourceGroups[*grp.ID] = ResourceGroup{
					Id:           *grp.ID,
					Name:         *grp.Name,
					Location:     *grp.Location,
					Type:         *grp.Type,
					Subscription: subscriptionId,
				}
			}
		}
	}
	return resourceGroups, nil
}

// GetSubscription gets subscription by ID
func (client *AzureClient) GetSubscription(ctx context.Context, subscriptionId string) (*Subscription, error) {
	sub, err := client.subscriptionsClient.Get(ctx, subscriptionId, nil)
	if err != nil {
		return nil, err
	}
	return &Subscription{
		ID:             *sub.ID,
		SubscriptionID: *sub.SubscriptionID,
		TenantID:       *sub.TenantID,
	}, err
}

// ListSubscriptions gets all subscriptions for a tenant
func (client *AzureClient) ListSubscriptions(ctx context.Context) (map[string]Subscription, error) {
	subs := map[string]Subscription{}
	pager := client.subscriptionsClient.NewListPager(nil)
	for pager.More() {
		page, err := pager.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		for _, v := range page.Value {
			subs[*v.SubscriptionID] = Subscription{
				ID:             *v.ID,
				SubscriptionID: *v.SubscriptionID,
				TenantID:       *v.TenantID,
			}
		}
	}
	return subs, nil
}

func (client *AzureClient) ListManagementGroupDescendentInfo(ctx context.Context, groupId string) ([]*armmanagementgroups.DescendantInfo, error) {

	pager := client.armmanagementClient.NewGetDescendantsPager(groupId, nil)
	var resourceGroups []*armmanagementgroups.DescendantInfo
	for pager.More() {
		resp, err := pager.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		if resp.DescendantListResult.Value != nil {
			resourceGroups = append(resourceGroups, resp.DescendantListResult.Value...)
		}
	}

	return resourceGroups, nil
}

func (client *AzureClient) ListLocationsForSubscriptionId(ctx context.Context, subscriptionId string) ([]LocationAssignment, error) {
	includeExtLocations := new(bool)
	locationAssignments := []LocationAssignment{}
	pager := client.subscriptionsClient.NewListLocationsPager(subscriptionId, &armsubscriptions.ClientListLocationsOptions{
		IncludeExtendedLocations: includeExtLocations,
	})
	for pager.More() {
		page, err := pager.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		for _, v := range page.Value {
			locationAssignments = append(locationAssignments, LocationAssignment{
				ID:                  v.ID,
				Name:                v.Name,
				RegionalDisplayName: v.RegionalDisplayName,
			})
		}
	}
	return locationAssignments, nil
}

// List all role assignments that apply to a resource group.
func (client *AzureClient) ListRolesForResourceGroup(ctx context.Context, groupID string) (map[string][]string, error) {
	roleAssignments := map[string][]string{}
	pager := client.roleAssignmentsClient.NewListForResourceGroupPager(groupID, &armauthorization.RoleAssignmentsClientListForResourceGroupOptions{
		// If need to query cross tenant, we need to use proper format tenant ID
		// TenantID: &client.Config.Tenant,
	})
	for pager.More() {
		page, err := pager.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		for _, v := range page.Value {
			if val, ok := roleAssignments[*v.Properties.PrincipalID]; ok {
				roleAssignments[*v.Properties.PrincipalID] = append(val, *v.Properties.RoleDefinitionID)
			} else {
				roleAssignments[*v.Properties.PrincipalID] = []string{*v.Properties.RoleDefinitionID}
			}
		}
	}
	return roleAssignments, nil
}

// ListRolesForSQLInstance method get list of roles for sql server
// For resourceProviderNamespace ref - https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/azure-services-resource-providers
// ForresourceType ref - https://learn.microsoft.com/en-us/azure/templates/microsoft.sql/allversions
func (client *AzureClient) ListRolesForSQLInstance(ctx context.Context, resourceGroupName, sqlServerNameName string) (map[string][]string, error) {
	roleAssignments := map[string][]string{}
	pager := client.roleAssignmentsClient.NewListForResourcePager(resourceGroupName, SQLResourceProviderNamespace, ServersResourceType, sqlServerNameName, &armauthorization.RoleAssignmentsClientListForResourceOptions{
		// If need to query cross tenant, we need to use proper format tenant ID
		// TenantID: &client.Config.Tenant,
	})
	for pager.More() {
		page, err := pager.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		for _, v := range page.Value {
			if val, ok := roleAssignments[*v.Properties.PrincipalID]; ok {
				roleAssignments[*v.Properties.PrincipalID] = append(val, *v.Properties.RoleDefinitionID)
			} else {
				roleAssignments[*v.Properties.PrincipalID] = []string{*v.Properties.RoleDefinitionID}
			}
		}
	}
	return roleAssignments, nil
}

// List all role assignments that apply to a subscription
func (client *AzureClient) ListRolesForSubscription(ctx context.Context, subscription string) (map[string][]string, error) {
	roleAssignments := map[string][]string{}
	pager := client.roleAssignmentsClient.NewListForScopePager(SubscriptionPrefix+subscription, &armauthorization.RoleAssignmentsClientListForScopeOptions{
		// If need to query cross tenant, we need to use proper format tenant ID
		// TenantID: &client.Config.Tenant,
	})
	for pager.More() {
		page, err := pager.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		for _, v := range page.Value {
			if val, ok := roleAssignments[*v.Properties.PrincipalID]; ok {
				roleAssignments[*v.Properties.PrincipalID] = append(val, *v.Properties.RoleDefinitionID)
			} else {
				roleAssignments[*v.Properties.PrincipalID] = []string{*v.Properties.RoleDefinitionID}
			}
		}
	}
	return roleAssignments, nil
}

// List all role assignments that apply to a management group
func (client *AzureClient) ListRolesForManagementGroup(ctx context.Context, managementgroup string) (map[string][]string, error) {
	roleAssignments := map[string][]string{}
	pager := client.roleAssignmentsClient.NewListForScopePager(managementgroup, &armauthorization.RoleAssignmentsClientListForScopeOptions{
		// If need to query cross tenant, we need to use proper format tenant ID
		// TenantID: &client.Config.Tenant,
	})
	for pager.More() {
		page, err := pager.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		for _, v := range page.Value {
			if val, ok := roleAssignments[*v.Properties.PrincipalID]; ok {
				roleAssignments[*v.Properties.PrincipalID] = append(val, *v.Properties.RoleDefinitionID)
			} else {
				roleAssignments[*v.Properties.PrincipalID] = []string{*v.Properties.RoleDefinitionID}
			}
		}
	}
	return roleAssignments, nil
}

// Get all role definitions that are applicable at scope and above.
func (client *AzureClient) GetRoleDefinitions(ctx context.Context) (map[string]RoleDefinition, error) {
	roleDefinitions := map[string]RoleDefinition{}
	pager := client.roleDefinitionsCLient.NewListPager("/", nil)
	for pager.More() {
		page, err := pager.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		for _, v := range page.Value {
			roleDefinitions[*v.ID] = RoleDefinition{
				ID:          *v.ID,
				Permissions: v.Properties.Permissions,
				Name:        *v.Name,
			}
		}
	}
	return roleDefinitions, nil
}

// GetSqlServerList method return list of available in ResourceGroup
func (client *AzureClient) GetSqlServerList(ctx context.Context, subscriptionId string, resourceGroupName string) (map[string]SqlServer, error) {
	serverList := map[string]SqlServer{}

	// SQL server Client
	sqlClientFactory, err := armsql.NewClientFactory(subscriptionId, client.azClientAssertionCredential, nil)
	if err != nil {
		return nil, err
	}
	client.serversClient = sqlClientFactory.NewServersClient()

	pager := client.serversClient.NewListByResourceGroupPager(resourceGroupName, &armsql.ServersClientListByResourceGroupOptions{})
	for pager.More() {
		page, err := pager.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		for _, v := range page.Value {
			serverList[*v.ID] = SqlServer{
				ID:            *v.ID,
				Name:          *v.Name,
				Type:          *v.Type,
				Kind:          *v.Kind,
				Location:      *v.Location,
				Tags:          v.Tags,
				ResourceGroup: resourceGroupName,
				Subscription:  subscriptionId,
			}
		}
	}
	return serverList, nil
}

// List gets list of groups for the current tenant.
func (client *AzureClient) ListGroups(ctx context.Context) (map[string]Group, error) {
	groupList := map[string]Group{}
	resp, err := client.groupClient.List(ctx, "")
	if err != nil {
		return nil, err
	}
	for _, group := range resp.Values() {
		members, err := client.ListGroupMembers(ctx, *group.ObjectID)
		if err != nil {
			return nil, errors.New("error getting group members: " + err.Error())
		}
		groupList[*group.ObjectID] = Group{
			Name:    *group.DisplayName,
			Id:      *group.ObjectID,
			Members: members,
		}
	}
	return groupList, err
}

// gets the members of a group
func (client *AzureClient) ListGroupMembers(ctx context.Context, groupObjectId string) ([]User, error) {
	userList := []User{}
	resp, err := client.groupClient.GetGroupMembers(ctx, groupObjectId)
	if err != nil {
		return nil, err
	}
	for _, member := range resp.Values() {

		user, isUser := member.AsUser()
		if isUser {
			userList = append(userList, User{
				Name:     *user.DisplayName,
				ID:       *user.ObjectID,
				UserType: string(user.UserType),
			})
		}
	}
	return userList, err
}

func Discover(ctx context.Context, client *AzureClient) (*DiscoveryResult, error) {
	result := new(DiscoveryResult)
	result.ManagementGroups = make(map[string]ManagementGroup)
	result.Subscriptions = make(map[string]Subscription)
	result.ResourceGroups = make(map[string]ResourceGroup)
	result.Users = make(map[string]User)
	result.Groups = make(map[string]Group)
	result.Roles = make(map[string]RoleDefinition)
	result.Instances = make(map[string]SqlServer)
	result.InstanceToUsers = make(map[string][]string)

	// get management groups
	managementGroups, err := client.ListManagementGroups(ctx)
	if err != nil {
		return nil, errors.New("error getting management groups: " + err.Error())
	}
	for id, grp := range managementGroups {
		// get and attach policies to management groups
		grp.Policy, err = client.ListRolesForManagementGroup(ctx, id)
		if err != nil {
			return nil, errors.New("error getting roles for management group: " + err.Error())
		}
	}
	result.ManagementGroups = managementGroups

	// get subscriptions
	subscriptions, err := client.ListSubscriptions(ctx)
	if err != nil {
		return nil, errors.New("error getting subscriptions: " + err.Error())
	}
	for id, sub := range subscriptions {
		// get and attach policies to subscriptions
		sub.Policy, err = client.ListRolesForSubscription(ctx, id)
		if err != nil {
			return nil, errors.New("error getting roles for subscriptions: " + err.Error())
		}

		// get resource groups
		resourceGroups, err := client.ListResourceGroupsForSubscription(ctx, id)
		if err != nil {
			return nil, errors.New("error getting resource groups for subscriptions: " + err.Error())
		}
		for groupID, group := range resourceGroups {
			// get and attach policies to resource groups
			group.Policy, err = client.ListRolesForResourceGroup(ctx, group.Name)
			if err != nil {
				return nil, errors.New("error getting roles for resource group: " + err.Error())
			}
			result.ResourceGroups[groupID] = group

			// get sql servers in the resource group
			instances, err := client.GetSqlServerList(ctx, id, group.Name)
			if err != nil {
				return nil, errors.New("error getting sql server list: " + err.Error())
			}

			for instanceID, instance := range instances {
				// get and attach policies to sql servers
				instance.Policy, err = client.ListRolesForSQLInstance(ctx, group.Name, instance.Name)
				if err != nil {
					return nil, errors.New("error getting roles for sql instance: " + err.Error())
				}
				result.Instances[instanceID] = instance

				// isolate users that hold Microsoft.Sql/servers permissions on that server
				instanceSQLUsers, err := getAuthorizedSQLUsers(result.Roles, instance.Policy)
				if err != nil {
					return nil, errors.New("error getting authorized sql users: " + err.Error())
				}
				result.InstanceToUsers[instanceID] = instanceSQLUsers
			}
		}
	}
	result.Subscriptions = subscriptions

	// get users
	users, err := client.ListUsers(ctx)
	if err != nil {
		return nil, errors.New("error getting users: " + err.Error())
	}
	result.Users = users

	// get groups
	groups, err := client.ListGroups(ctx)
	if err != nil {
		return nil, errors.New("error getting groups: " + err.Error())
	}
	result.Groups = groups

	return result, nil
}

// checks for users that have Microsoft.Sql/servers permissions on an sql server
func getAuthorizedSQLUsers(roledefs map[string]RoleDefinition, policy map[string][]string) ([]string, error) {
	users := []string{}
	for user, roles := range policy {
		found := false
		for _, role := range roles {
			def, ok := roledefs[role]
			if !ok {
				return nil, errors.New("unknown role: " + role)
			}
			for _, perm := range def.Permissions {
				for _, action := range perm.Actions {
					if strings.HasPrefix(*action, "Microsoft.Sql/servers/") {
						users = append(users, user)
						found = true
						break
					}
				}
				if found {
					break
				}
			}
			if found {
				break
			}
		}
	}
	return users, nil
}
