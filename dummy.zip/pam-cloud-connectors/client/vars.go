package client

// Entity name prefixes
const (
	UserPrefix                  = "user:"
	ServiceAccountPrefix        = "serviceAccount:"
	GroupPrefix                 = "group:"
	OrganizationPrefix          = "organizations/"
	ProjectPrefix               = "projects/"
	ProjectServiceAccountPrefix = "projects/-/serviceAccounts/"
)

// Configuration static strings
const (
	ExternalAccountType                        = "external_account"
	AudienceFormatString                       = "//iam.googleapis.com/projects/%s/locations/global/workloadIdentityPools/%s/providers/%s"
	ServiceAccountImpersonationUrlFormatString = "https://iamcredentials.googleapis.com/v1/projects/-/serviceAccounts/%s:generateAccessToken"
	TokenUrl                                   = "https://sts.googleapis.com/v1/token"
	EnvironmentId                              = "aws1"
	RegionUrl                                  = "http://169.254.169.254/latest/meta-data/placement/availability-zone"
	Url                                        = "http://169.254.169.254/latest/meta-data/iam/security-credentials"
	RegionalCredVerificationUrl                = "https://sts.{region}.amazonaws.com?Action=GetCallerIdentity&Version=2011-06-15"
	SubjectTokenType                           = "urn:ietf:params:aws:token-type:aws4_request"
)
