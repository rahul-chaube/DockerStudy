# Create role
aws iam create-role --role-name GCPConnectorTestRole --assume-role-policy-document trust-policy.json
# Attach policies
aws iam attach-role-policy --role-name GCPConnectorTestRole --policy-arn arn:aws:iam:aws:policy/AmazonEKSWorkerNodePolicy
aws iam attach-role-policy --role-name GCPConnectorTestRole --policy-arn arn:aws:iam:aws:policy/AmazonEC2ContainerRegistryReadOnly
aws iam attach-role-policy --role-name GCPConnectorTestRole --policy-arn arn:aws:iam:aws:policy/AmazonEKS_CNI_Policy 
