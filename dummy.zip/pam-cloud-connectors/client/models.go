package client

type Binding struct {
	Role    string
	Members []string
}

type UserRoleBinding struct {
	Roles  []GCPRole
	Member GCPUserDetails
}

type GroupRoleBinding struct {
	Roles  []GCPRole
	Member GCPGroupDetails
}

type ServiceAccountRoleBinding struct {
	Roles  []GCPRole
	Member GCPServiceAccountDetails
}

// GCPServiceAccountDetails maps Account details
// EXAMPLE:
// Id:10398679209378471234
// Name:projects/my-pam-project/serviceAccounts/123456789012-compute@developer.gserviceaccount.com
// Email:123456789012-compute@developer.gserviceaccount.com
type GCPServiceAccountDetails struct {
	Id          string
	Name        string
	Email       string
	Disabled    bool
	ProjectId   string
	DisplayName string
}

// GCPUserDetails maps User details
// EXAMPLE:
// Id:11322548121559324397
// Name: Example
// FullName:Example Full Name
// Email:example.pam@pam-gcp.com
type GCPUserDetails struct {
	Id               string
	Name             string
	FullName         string
	Email            string
	isAdmin          bool
	IsDelegatedAdmin bool
	Suspended        bool
	OrgUnitPath      string
}

// GCPGroupDetails maps Group details
// EXAMPLE:
// Id:11qoc5b123l9om3
// Name:pam-connector-group
// Members:[123456789012345678901 098765432123456789098]
// Email:pam-connector-group@pam-gcp.example.com
type GCPGroupDetails struct {
	Id                 string
	Name               string
	Members            []string
	Email              string
	AdminCreated       bool
	Description        string
	Aliases            []string
	DirectMembersCount int64
	Etag               string
	NonEditableAliases []string
}

// A GCP Folder is an IAM resource that groups projects for access management
// EXAMPLE;
// Policy:0xc000347d20
// Name:folders/84957544909
// DisplayName:pam-connectors
// Parent:
// State:0
// Id:
type GCPFolderDetails struct {
	Policy      *GCPPolicy
	Name        string
	DisplayName string
	Parent      string
	State       int32
	Id          string
}

type GCPProjectDetails struct {
	Id     string
	Name   string
	Folder string
}

// GCPRole maps Role Details
// EXAMPLE:
// Name:roles/example
// Title: Description:Some description of the role.
// IncludedPermissions:[accessapproval.requests.approveexample accessapproval.requests.example1 accessapproval.requests.getexample accessapproval.requests.ownerexample]
// Stage:GA
// ETag:EX==
type GCPRole struct {
	Name                string   `json:"name"`
	Title               string   `json:"title"`
	Description         string   `json:"description"`
	IncludedPermissions []string `json:"includedPermissions,omitempty"`
	Stage               string   `json:"stage"`
	ETag                string   `json:"etag"`
	Deleted             bool     `json:"deleted,omitempty"`
}

// GCPRole maps List of instances
// EXAMPLE:
// Id:pam-connector-project
// Name:pam-connector-project-name
// Region:us-central
// Project:my-pam-project-2-410614
type GCPSQLInstanceDetails struct {
	Id                       string
	Name                     string
	Region                   string
	Project                  string
	DatabaseInstalledVersion string
	GCEZone                  string
	MaxDiskSize              int64
	SecondaryGceZone         string
	SelfLink                 string
	SqlNetworkArchitecture   string
	State                    string
}

// GCPSQLUserDetails maps a user to the roles it holds on SQL instances
type GCPSQLUserDetails struct {
	Name    string
	Host    string
	Type    string
	Roles   []string
	Project string
}

// GcpSqlDiscoveryResult
type GcpSqlDiscoveryResult struct {
	GCPSQLInstances                 []GCPSQLInstanceDetails             // List of instances
	Users                           map[string]GCPUserDetails           // User Email to User Details
	Groups                          map[string]GCPGroupDetails          // Group Email to Group Details
	ServiceAccounts                 map[string]GCPServiceAccountDetails // Service Account Email to Service Account Details
	Roles                           map[string]GCPRole                  // Role name to Role Details
	Folders                         map[string]GCPFolderDetails         // Folder Number to Folder Details
	FolderToProjects                map[string][]GCPProjectDetails      // Folder Number to list of projects
	GCPSQLInstanceToUsers           map[string]map[string][]string      // Instance ID to User Email to list of roles
	GCPSQLInstanceToGroups          map[string]map[string][]string      // Instance ID to Group Email to list of roles
	GCPSQLInstanceToServiceAccounts map[string]map[string][]string      // Instance ID to Service Account Email to list of roles
	GCPSqlUser                      map[string][]GCPSQLUserDetails      // Instance ID to user list
}

type ListProjectInstanceDetailsResponse struct {
	Roles                           map[string]GCPRole             // Role name to Role Details
	Instances                       []GCPSQLInstanceDetails        // List of instances
	GCPSQLInstanceToUsers           map[string]map[string][]string // Instance ID to User Email to list of roles
	GCPSQLInstanceToGroups          map[string]map[string][]string // Instance ID to Group Email to list of roles
	GCPSQLInstanceToServiceAccounts map[string]map[string][]string // Instance ID to Service Account Email to list of roles
}

type GCPPolicy struct {
	Roles                map[string]GCPRole  // Role name to Role Details
	UserPolicy           map[string][]string // User Email to list of roles
	GroupPolicy          map[string][]string // Instance ID to Group Email to list of roles
	ServiceAccountPolicy map[string][]string // Instance ID to Service Account Email to list of roles
}

type ExcessRole struct {
	Member string
	Role   string
}

type PaginationFilter struct {
	Count int64 // Controls the number of objects listed per page
}

type DiscoveryPaginationFilter struct {
	UserPagination     *PaginationFilter
	GroupPagination    *PaginationFilter
	FolderPagination   *PaginationFilter
	ProjectPagination  *PaginationFilter
	InstancePagination *PaginationFilter
}
