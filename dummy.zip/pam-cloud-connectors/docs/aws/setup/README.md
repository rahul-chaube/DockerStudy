# Resource Setup

## Assigned Role

No special policies are needed for the role assigned to the resource that will perform the workload.
The google side needs to be aware of:
- AWS Accound ID
- Role
- Instance ID

## Instance settings

On the instance that will perform the workload, go to Actions > Instance Settings > Modify instance metadata options, set IMDSv2 to Optional.
This is needed because the federated identity requires IMDSv1 calls.